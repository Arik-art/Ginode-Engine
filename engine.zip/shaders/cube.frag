#version 450
layout(set = 0, binding = 0) uniform Scene { vec4 lightDir; vec4 lightColor; vec4 ambient; vec4 camPos; vec4 fog; } sc;
layout(location = 0) in vec3 vNormal;
layout(location = 1) in vec3 vColor;
layout(location = 2) in vec3 vWorld;
layout(location = 3) flat in float vFlag;   // 1 normal, 2 checker floor, +0.5 selected
layout(location = 0) out vec4 outColor;
void main() {
    vec3 base = vColor;
    if (vFlag >= 1.75) {
        float ch = mod(floor(vWorld.x) + floor(vWorld.z), 2.0);
        base *= mix(0.7, 1.0, ch);
    }
    vec3 N = normalize(vNormal);
    vec3 L = normalize(sc.lightDir.xyz);
    float ndl = max(dot(N, L), 0.0);
    vec3 amb = mix(vec3(0.04, 0.045, 0.05), sc.ambient.rgb, N.y * 0.5 + 0.5);
    vec3 V = normalize(sc.camPos.xyz - vWorld);
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 48.0) * 0.25;
    float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.18;
    vec3 c = base * (amb + ndl * sc.lightColor.rgb) + spec * ndl * sc.lightColor.rgb + rim * sc.ambient.rgb * 2.0;
    if (fract(vFlag) > 0.25) c = mix(c, vec3(1.0, 0.75, 0.15), 0.35);
    float d = length(sc.camPos.xyz - vWorld);
    c = mix(c, sc.fog.rgb, 1.0 - exp(-d * sc.fog.w));
    outColor = vec4(c, 1.0);
}
