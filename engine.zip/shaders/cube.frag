#version 450
layout(set = 0, binding = 0) uniform Scene { vec4 lightDir; vec4 lightColor; vec4 ambient; vec4 camPos; } sc;
layout(location = 0) in vec3 vNormal;
layout(location = 1) in vec3 vColor;
layout(location = 2) in vec3 vWorld;
layout(location = 0) out vec4 outColor;
void main() {
    vec3 N = normalize(vNormal);
    vec3 L = normalize(sc.lightDir.xyz);
    float ndl = max(dot(N, L), 0.0);
    vec3 amb = sc.ambient.rgb * (0.6 + 0.4 * N.y);
    vec3 V = normalize(sc.camPos.xyz - vWorld);
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 48.0) * 0.25;
    vec3 c = vColor * (amb + ndl * sc.lightColor.rgb) + spec * ndl * sc.lightColor.rgb;
    outColor = vec4(c, 1.0);
}
