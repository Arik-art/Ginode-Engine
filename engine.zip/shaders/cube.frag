#version 450
layout(location = 0) in vec3 vNormal;
layout(location = 1) in vec3 vColor;
layout(location = 2) in vec3 vWorld;
layout(location = 0) out vec4 outColor;
void main() {
    vec3 N = normalize(vNormal);
    vec3 L = normalize(vec3(0.5, 1.0, 0.6));
    float ndl = max(dot(N, L), 0.0);
    vec3 amb = mix(vec3(0.03, 0.03, 0.03), vec3(0.08, 0.11, 0.18), N.y * 0.5 + 0.5);
    vec3 V = normalize(vec3(0.0, 1.5, 4.0) - vWorld);
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 48.0) * 0.35;
    vec3 c = vColor * (amb + ndl * vec3(1.0, 0.96, 0.9)) + spec * ndl;
    outColor = vec4(c, 1.0);
}
