#version 450
layout(location = 0) in vec3 inPos;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec3 inColor;
// 128 bytes: mvp + 3 model rows + color
layout(push_constant) uniform PC { mat4 mvp; vec4 m0; vec4 m1; vec4 m2; vec4 color; } pc;
layout(location = 0) out vec3 vNormal;
layout(location = 1) out vec3 vColor;
layout(location = 2) out vec3 vWorld;
layout(location = 3) flat out float vFlag;
void main() {
    vec4 p = vec4(inPos, 1.0);
    gl_Position = pc.mvp * p;
    vWorld = vec3(dot(pc.m0, p), dot(pc.m1, p), dot(pc.m2, p));
    vNormal = vec3(dot(pc.m0.xyz, inNormal), dot(pc.m1.xyz, inNormal), dot(pc.m2.xyz, inNormal));
    vFlag = pc.color.a;
    vColor = pow(pc.color.rgb, vec3(2.2)) * inColor;
}
