// Ginode engine: Vulkan renderer + node tree + Gino scripting, for Android (NativeActivity).
#include <android_native_app_glue.h>
#include <android/asset_manager.h>
#include <android/input.h>
#include <android/log.h>
#include <android/native_window.h>
#include <vulkan/vulkan.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <string>
#include <vector>

#include "gino.h"
#include "mesh.h"
#include "shaders.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "Ginode", __VA_ARGS__)
#define VK_CHECK(x)                                                              \
    do {                                                                         \
        VkResult r_ = (x);                                                       \
        if (r_ != VK_SUCCESS) {                                                  \
            LOG("Vulkan error %d at %s:%d", (int)r_, __FILE__, __LINE__);        \
            abort();                                                             \
        }                                                                        \
    } while (0)

// ------------------------------------------------------------------ math
struct Mat4 { float m[16]; };  // column-major
static Vec3 sub(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static float dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static Vec3 norm(Vec3 a) {
    float l = std::sqrt(dot(a, a));
    if (l < 1e-9f) return {0, 1, 0};
    return {a.x / l, a.y / l, a.z / l};
}
static Mat4 identity() { Mat4 r{}; r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.f; return r; }
static Mat4 mul(const Mat4& a, const Mat4& b) {
    Mat4 r{};
    for (int c = 0; c < 4; c++)
        for (int row = 0; row < 4; row++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + row] * b.m[c * 4 + k];
            r.m[c * 4 + row] = s;
        }
    return r;
}
static Mat4 rotX(float a) { Mat4 r = identity(); float c = std::cos(a), s = std::sin(a); r.m[5] = c; r.m[6] = s; r.m[9] = -s; r.m[10] = c; return r; }
static Mat4 rotY(float a) { Mat4 r = identity(); float c = std::cos(a), s = std::sin(a); r.m[0] = c; r.m[2] = -s; r.m[8] = s; r.m[10] = c; return r; }
static Mat4 rotZ(float a) { Mat4 r = identity(); float c = std::cos(a), s = std::sin(a); r.m[0] = c; r.m[1] = s; r.m[4] = -s; r.m[5] = c; return r; }
static Mat4 perspective(float fovy, float aspect, float n, float f) {
    float t = 1.f / std::tan(fovy * 0.5f);
    Mat4 r{};
    r.m[0] = t / aspect; r.m[5] = -t;  // Vulkan: Y down
    r.m[10] = f / (n - f); r.m[11] = -1.f; r.m[14] = n * f / (n - f);
    return r;
}
static Mat4 lookAt(Vec3 eye, Vec3 center, Vec3 up) {
    Vec3 f = norm(sub(center, eye));
    Vec3 s = {f.y * up.z - f.z * up.y, f.z * up.x - f.x * up.z, f.x * up.y - f.y * up.x};
    s = norm(s);
    Vec3 u = {s.y * f.z - s.z * f.y, s.z * f.x - s.x * f.z, s.x * f.y - s.y * f.x};
    Mat4 r = identity();
    r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
    r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
    r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
    r.m[12] = -dot(s, eye); r.m[13] = -dot(u, eye); r.m[14] = dot(f, eye);
    return r;
}
static const float kDeg = 3.14159265f / 180.f;
static Mat4 localMatrix(const gino::Node* n) {
    Mat4 T = identity(), S = identity();
    T.m[12] = n->pos.x; T.m[13] = n->pos.y; T.m[14] = n->pos.z;
    S.m[0] = n->scl.x; S.m[5] = n->scl.y; S.m[10] = n->scl.z;
    return mul(T, mul(rotY(n->rot.y * kDeg), mul(rotX(n->rot.x * kDeg), mul(rotZ(n->rot.z * kDeg), S))));
}
// View matrix from a camera's world matrix (rotation + translation, scale ignored).
static Mat4 viewFromWorld(const Mat4& W) {
    Vec3 c0 = norm({W.m[0], W.m[1], W.m[2]}), c1 = norm({W.m[4], W.m[5], W.m[6]}),
         c2 = norm({W.m[8], W.m[9], W.m[10]}), t = {W.m[12], W.m[13], W.m[14]};
    Mat4 r = identity();
    r.m[0] = c0.x; r.m[4] = c0.y; r.m[8] = c0.z;
    r.m[1] = c1.x; r.m[5] = c1.y; r.m[9] = c1.z;
    r.m[2] = c2.x; r.m[6] = c2.y; r.m[10] = c2.z;
    r.m[12] = -dot(c0, t); r.m[13] = -dot(c1, t); r.m[14] = -dot(c2, t);
    return r;
}

// ------------------------------------------------------------------ 5x7 font (ASCII 32..126)
static const uint8_t kFont[95 * 5] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x5F, 0x00, 0x00, 0x00, 0x07, 0x00, 0x07, 0x00, 0x14, 0x7F, 0x14, 0x7F, 0x14, 0x24, 0x2A, 0x7F, 0x2A, 0x12, 0x23, 0x13, 0x08, 0x64, 0x62, 0x36, 0x49, 0x55, 0x22, 0x50, 0x00, 0x05, 0x03, 0x00, 0x00,
    0x00, 0x1C, 0x22, 0x41, 0x00, 0x00, 0x41, 0x22, 0x1C, 0x00, 0x14, 0x08, 0x3E, 0x08, 0x14, 0x08, 0x08, 0x3E, 0x08, 0x08, 0x00, 0x50, 0x30, 0x00, 0x00, 0x08, 0x08, 0x08, 0x08, 0x08, 0x00, 0x60, 0x60, 0x00, 0x00, 0x20, 0x10, 0x08, 0x04, 0x02,
    0x3E, 0x51, 0x49, 0x45, 0x3E, 0x00, 0x42, 0x7F, 0x40, 0x00, 0x42, 0x61, 0x51, 0x49, 0x46, 0x21, 0x41, 0x45, 0x4B, 0x31, 0x18, 0x14, 0x12, 0x7F, 0x10, 0x27, 0x45, 0x45, 0x45, 0x39, 0x3C, 0x4A, 0x49, 0x49, 0x30, 0x01, 0x71, 0x09, 0x05, 0x03,
    0x36, 0x49, 0x49, 0x49, 0x36, 0x06, 0x49, 0x49, 0x29, 0x1E, 0x00, 0x36, 0x36, 0x00, 0x00, 0x00, 0x56, 0x36, 0x00, 0x00, 0x08, 0x14, 0x22, 0x41, 0x00, 0x14, 0x14, 0x14, 0x14, 0x14, 0x00, 0x41, 0x22, 0x14, 0x08, 0x02, 0x01, 0x51, 0x09, 0x06,
    0x32, 0x49, 0x79, 0x41, 0x3E, 0x7E, 0x11, 0x11, 0x11, 0x7E, 0x7F, 0x49, 0x49, 0x49, 0x36, 0x3E, 0x41, 0x41, 0x41, 0x22, 0x7F, 0x41, 0x41, 0x22, 0x1C, 0x7F, 0x49, 0x49, 0x49, 0x41, 0x7F, 0x09, 0x09, 0x09, 0x01, 0x3E, 0x41, 0x49, 0x49, 0x7A,
    0x7F, 0x08, 0x08, 0x08, 0x7F, 0x00, 0x41, 0x7F, 0x41, 0x00, 0x20, 0x40, 0x41, 0x3F, 0x01, 0x7F, 0x08, 0x14, 0x22, 0x41, 0x7F, 0x40, 0x40, 0x40, 0x40, 0x7F, 0x02, 0x0C, 0x02, 0x7F, 0x7F, 0x04, 0x08, 0x10, 0x7F, 0x3E, 0x41, 0x41, 0x41, 0x3E,
    0x7F, 0x09, 0x09, 0x09, 0x06, 0x3E, 0x41, 0x51, 0x21, 0x5E, 0x7F, 0x09, 0x19, 0x29, 0x46, 0x46, 0x49, 0x49, 0x49, 0x31, 0x01, 0x01, 0x7F, 0x01, 0x01, 0x3F, 0x40, 0x40, 0x40, 0x3F, 0x1F, 0x20, 0x40, 0x20, 0x1F, 0x3F, 0x40, 0x38, 0x40, 0x3F,
    0x63, 0x14, 0x08, 0x14, 0x63, 0x07, 0x08, 0x70, 0x08, 0x07, 0x61, 0x51, 0x49, 0x45, 0x43, 0x00, 0x7F, 0x41, 0x41, 0x00, 0x02, 0x04, 0x08, 0x10, 0x20, 0x00, 0x41, 0x41, 0x7F, 0x00, 0x04, 0x02, 0x01, 0x02, 0x04, 0x40, 0x40, 0x40, 0x40, 0x40,
    0x00, 0x01, 0x02, 0x04, 0x00, 0x20, 0x54, 0x54, 0x54, 0x78, 0x7F, 0x48, 0x44, 0x44, 0x38, 0x38, 0x44, 0x44, 0x44, 0x20, 0x38, 0x44, 0x44, 0x48, 0x7F, 0x38, 0x54, 0x54, 0x54, 0x18, 0x08, 0x7E, 0x09, 0x01, 0x02, 0x0C, 0x52, 0x52, 0x52, 0x3E,
    0x7F, 0x08, 0x04, 0x04, 0x78, 0x00, 0x44, 0x7D, 0x40, 0x00, 0x20, 0x40, 0x44, 0x3D, 0x00, 0x7F, 0x10, 0x28, 0x44, 0x00, 0x00, 0x41, 0x7F, 0x40, 0x00, 0x7C, 0x04, 0x18, 0x04, 0x78, 0x7C, 0x08, 0x04, 0x04, 0x78, 0x38, 0x44, 0x44, 0x44, 0x38,
    0x7C, 0x14, 0x14, 0x14, 0x08, 0x08, 0x14, 0x14, 0x18, 0x7C, 0x7C, 0x08, 0x04, 0x04, 0x08, 0x48, 0x54, 0x54, 0x54, 0x20, 0x04, 0x3F, 0x44, 0x40, 0x20, 0x3C, 0x40, 0x40, 0x20, 0x7C, 0x1C, 0x20, 0x40, 0x20, 0x1C, 0x3C, 0x40, 0x30, 0x40, 0x3C,
    0x44, 0x28, 0x10, 0x28, 0x44, 0x0C, 0x50, 0x50, 0x50, 0x3C, 0x44, 0x64, 0x54, 0x4C, 0x44, 0x00, 0x08, 0x36, 0x41, 0x00, 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00, 0x41, 0x36, 0x08, 0x00, 0x08, 0x08, 0x2A, 0x1C, 0x08,
};

// ------------------------------------------------------------------ engine state
static const int kFrames = 2;
static const uint32_t kUiMaxVerts = 40000;
struct UiVert { float x, y, r, g, b, a; };
struct PushData { float mvp[16]; float m0[4], m1[4], m2[4]; float color[4]; };
static_assert(sizeof(PushData) == 128, "push constants must be 128 bytes");
struct SceneUbo { float lightDir[4], lightColor[4], ambient[4], camPos[4]; };

struct Engine {
    android_app* app = nullptr;
    bool ready = false, needRecreate = false;

    VkInstance instance = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice dev = VK_NULL_HANDLE;
    uint32_t qfam = 0;
    VkQueue queue = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE;
    VkCommandBuffer cmd[kFrames] = {};
    VkSemaphore imgAvail[kFrames] = {};
    VkFence fence[kFrames] = {};
    VkDescriptorSetLayout setLayout = VK_NULL_HANDLE;
    VkDescriptorPool descPool = VK_NULL_HANDLE;
    VkDescriptorSet sets[kFrames] = {};
    VkBuffer ubo[kFrames] = {};
    VkDeviceMemory uboMem[kFrames] = {};
    SceneUbo* uboPtr[kFrames] = {};
    VkPipelineLayout pipeLayout = VK_NULL_HANDLE, uiLayout = VK_NULL_HANDLE;
    VkBuffer vbuf = VK_NULL_HANDLE, ibuf = VK_NULL_HANDLE;
    VkDeviceMemory vmem = VK_NULL_HANDLE, imem = VK_NULL_HANDLE;
    VkBuffer uiBuf[kFrames] = {};
    VkDeviceMemory uiMem[kFrames] = {};
    UiVert* uiPtr[kFrames] = {};
    uint32_t uiCount = 0;
    MeshSet meshes;
    int frame = 0;

    VkSurfaceKHR surface = VK_NULL_HANDLE;
    VkSwapchainKHR swapchain = VK_NULL_HANDLE;
    VkFormat colorFormat = VK_FORMAT_UNDEFINED;
    VkExtent2D extent{};
    std::vector<VkImage> images;
    std::vector<VkImageView> views;
    std::vector<VkFramebuffer> fbs;
    std::vector<VkSemaphore> renderDone;
    VkImage depthImg = VK_NULL_HANDLE;
    VkDeviceMemory depthMem = VK_NULL_HANDLE;
    VkImageView depthView = VK_NULL_HANDLE;
    VkRenderPass rp = VK_NULL_HANDLE;
    VkPipeline pipeline = VK_NULL_HANDLE, uiPipeline = VK_NULL_HANDLE;

    // game
    gino::Scene scene;
    bool sceneOk = false;
    std::string sceneErr;
    std::deque<std::string> logLines;
    float lastX = 0, lastY = 0;
    bool dragging = false;
    std::chrono::steady_clock::time_point last;
    float fpsTimer = 0, fps = 0, gameTime = 0;
    int fpsFrames = 0;
};
static Engine g;

// ------------------------------------------------------------------ vulkan helpers
static uint32_t findMem(uint32_t bits, VkMemoryPropertyFlags want) {
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(g.phys, &mp);
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & want) == want) return i;
    LOG("no memory type");
    abort();
}

static void createMapped(VkDeviceSize size, VkBufferUsageFlags usage, VkBuffer& buf,
                         VkDeviceMemory& mem, void** ptr) {
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size;
    bi.usage = usage;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VK_CHECK(vkCreateBuffer(g.dev, &bi, nullptr, &buf));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(g.dev, buf, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
                                                        VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    VK_CHECK(vkAllocateMemory(g.dev, &ai, nullptr, &mem));
    VK_CHECK(vkBindBufferMemory(g.dev, buf, mem, 0));
    VK_CHECK(vkMapMemory(g.dev, mem, 0, size, 0, ptr));
}

static void makeStaticBuffer(const void* data, VkDeviceSize size, VkBufferUsageFlags usage,
                             VkBuffer& buf, VkDeviceMemory& mem) {
    void* p;
    createMapped(size, usage, buf, mem, &p);
    memcpy(p, data, (size_t)size);
    vkUnmapMemory(g.dev, mem);
}

static VkShaderModule makeShader(const uint32_t* code, size_t bytes) {
    VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    ci.codeSize = bytes;
    ci.pCode = code;
    VkShaderModule m;
    VK_CHECK(vkCreateShaderModule(g.dev, &ci, nullptr, &m));
    return m;
}

// ------------------------------------------------------------------ init (once)
static void createInstance() {
    const char* exts[] = {"VK_KHR_surface", "VK_KHR_android_surface"};
    VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.pApplicationName = "Ginode";
    ai.apiVersion = VK_API_VERSION_1_0;
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &ai;
    ci.enabledExtensionCount = 2;
    ci.ppEnabledExtensionNames = exts;
    VK_CHECK(vkCreateInstance(&ci, nullptr, &g.instance));
}

static void createSurface() {
    VkAndroidSurfaceCreateInfoKHR ci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    ci.window = g.app->window;
    VK_CHECK(vkCreateAndroidSurfaceKHR(g.instance, &ci, nullptr, &g.surface));
}

static void createDeviceAndResources() {
    uint32_t n = 0;
    vkEnumeratePhysicalDevices(g.instance, &n, nullptr);
    std::vector<VkPhysicalDevice> pds(n);
    vkEnumeratePhysicalDevices(g.instance, &n, pds.data());
    g.phys = VK_NULL_HANDLE;
    for (auto pd : pds) {
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qs(qn);
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, qs.data());
        for (uint32_t i = 0; i < qn; i++) {
            VkBool32 present = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, g.surface, &present);
            if ((qs[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && present) { g.phys = pd; g.qfam = i; break; }
        }
        if (g.phys) break;
    }
    if (!g.phys) { LOG("no suitable GPU"); abort(); }
    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(g.phys, &props);
    LOG("GPU: %s", props.deviceName);

    float prio = 1.f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = g.qfam;
    qci.queueCount = 1;
    qci.pQueuePriorities = &prio;
    const char* dexts[] = {"VK_KHR_swapchain"};
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1;
    dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = 1;
    dci.ppEnabledExtensionNames = dexts;
    VK_CHECK(vkCreateDevice(g.phys, &dci, nullptr, &g.dev));
    vkGetDeviceQueue(g.dev, g.qfam, 0, &g.queue);

    VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    pci.queueFamilyIndex = g.qfam;
    VK_CHECK(vkCreateCommandPool(g.dev, &pci, nullptr, &g.pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = g.pool;
    cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cai.commandBufferCount = kFrames;
    VK_CHECK(vkAllocateCommandBuffers(g.dev, &cai, g.cmd));
    for (int i = 0; i < kFrames; i++) {
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VK_CHECK(vkCreateSemaphore(g.dev, &si, nullptr, &g.imgAvail[i]));
        VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        VK_CHECK(vkCreateFence(g.dev, &fi, nullptr, &g.fence[i]));
    }

    // descriptor set: one uniform buffer (scene light/camera) per frame in flight
    VkDescriptorSetLayoutBinding b{};
    b.binding = 0;
    b.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    b.descriptorCount = 1;
    b.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo dlci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dlci.bindingCount = 1;
    dlci.pBindings = &b;
    VK_CHECK(vkCreateDescriptorSetLayout(g.dev, &dlci, nullptr, &g.setLayout));
    VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, kFrames};
    VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpci.maxSets = kFrames;
    dpci.poolSizeCount = 1;
    dpci.pPoolSizes = &ps;
    VK_CHECK(vkCreateDescriptorPool(g.dev, &dpci, nullptr, &g.descPool));
    VkDescriptorSetLayout layouts[kFrames] = {g.setLayout, g.setLayout};
    VkDescriptorSetAllocateInfo dsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dsai.descriptorPool = g.descPool;
    dsai.descriptorSetCount = kFrames;
    dsai.pSetLayouts = layouts;
    VK_CHECK(vkAllocateDescriptorSets(g.dev, &dsai, g.sets));
    for (int i = 0; i < kFrames; i++) {
        void* p;
        createMapped(sizeof(SceneUbo), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, g.ubo[i], g.uboMem[i], &p);
        g.uboPtr[i] = (SceneUbo*)p;
        VkDescriptorBufferInfo bi{g.ubo[i], 0, sizeof(SceneUbo)};
        VkWriteDescriptorSet w{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
        w.dstSet = g.sets[i];
        w.dstBinding = 0;
        w.descriptorCount = 1;
        w.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        w.pBufferInfo = &bi;
        vkUpdateDescriptorSets(g.dev, 1, &w, 0, nullptr);
        void* up;
        createMapped(kUiMaxVerts * sizeof(UiVert), VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, g.uiBuf[i], g.uiMem[i], &up);
        g.uiPtr[i] = (UiVert*)up;
    }

    VkPushConstantRange pcr{VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(PushData)};
    VkPipelineLayoutCreateInfo lci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    lci.setLayoutCount = 1;
    lci.pSetLayouts = &g.setLayout;
    lci.pushConstantRangeCount = 1;
    lci.pPushConstantRanges = &pcr;
    VK_CHECK(vkCreatePipelineLayout(g.dev, &lci, nullptr, &g.pipeLayout));
    VkPipelineLayoutCreateInfo uli{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    VK_CHECK(vkCreatePipelineLayout(g.dev, &uli, nullptr, &g.uiLayout));

    g.meshes = buildMeshes();
    makeStaticBuffer(g.meshes.vs.data(), g.meshes.vs.size() * sizeof(Vertex),
                     VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, g.vbuf, g.vmem);
    makeStaticBuffer(g.meshes.is.data(), g.meshes.is.size() * sizeof(uint16_t),
                     VK_BUFFER_USAGE_INDEX_BUFFER_BIT, g.ibuf, g.imem);
}

// ------------------------------------------------------------------ swapchain-dependent
static void destroySwapchainStuff() {
    if (!g.dev) return;
    vkDeviceWaitIdle(g.dev);
    if (g.pipeline) vkDestroyPipeline(g.dev, g.pipeline, nullptr);
    if (g.uiPipeline) vkDestroyPipeline(g.dev, g.uiPipeline, nullptr);
    if (g.rp) vkDestroyRenderPass(g.dev, g.rp, nullptr);
    for (auto f : g.fbs) vkDestroyFramebuffer(g.dev, f, nullptr);
    for (auto v : g.views) vkDestroyImageView(g.dev, v, nullptr);
    for (auto s : g.renderDone) vkDestroySemaphore(g.dev, s, nullptr);
    if (g.depthView) vkDestroyImageView(g.dev, g.depthView, nullptr);
    if (g.depthImg) vkDestroyImage(g.dev, g.depthImg, nullptr);
    if (g.depthMem) vkFreeMemory(g.dev, g.depthMem, nullptr);
    if (g.swapchain) vkDestroySwapchainKHR(g.dev, g.swapchain, nullptr);
    g.pipeline = g.uiPipeline = VK_NULL_HANDLE;
    g.rp = VK_NULL_HANDLE;
    g.fbs.clear(); g.views.clear(); g.renderDone.clear(); g.images.clear();
    g.depthView = VK_NULL_HANDLE; g.depthImg = VK_NULL_HANDLE; g.depthMem = VK_NULL_HANDLE;
    g.swapchain = VK_NULL_HANDLE;
}

static VkPipeline createPipeline(bool ui) {
    VkShaderModule vsm = ui ? makeShader(kUiVertSpv, sizeof(kUiVertSpv)) : makeShader(kVertSpv, sizeof(kVertSpv));
    VkShaderModule fsm = ui ? makeShader(kUiFragSpv, sizeof(kUiFragSpv)) : makeShader(kFragSpv, sizeof(kFragSpv));
    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    st[0].module = vsm;
    st[0].pName = "main";
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    st[1].module = fsm;
    st[1].pName = "main";

    VkVertexInputBindingDescription bind{0, ui ? (uint32_t)sizeof(UiVert) : (uint32_t)sizeof(Vertex),
                                         VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription attr3[3] = {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex, pos)},
        {1, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex, nrm)},
        {2, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex, col)}};
    VkVertexInputAttributeDescription attr2[2] = {
        {0, 0, VK_FORMAT_R32G32_SFLOAT, 0},
        {1, 0, VK_FORMAT_R32G32B32A32_SFLOAT, 8}};
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    vin.vertexBindingDescriptionCount = 1;
    vin.pVertexBindingDescriptions = &bind;
    vin.vertexAttributeDescriptionCount = ui ? 2 : 3;
    vin.pVertexAttributeDescriptions = ui ? attr2 : attr3;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1;
    vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    rs.cullMode = ui ? VK_CULL_MODE_NONE : VK_CULL_MODE_BACK_BIT;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    ds.depthTestEnable = ui ? VK_FALSE : VK_TRUE;
    ds.depthWriteEnable = ui ? VK_FALSE : VK_TRUE;
    ds.depthCompareOp = VK_COMPARE_OP_LESS;
    VkPipelineColorBlendAttachmentState cba{};
    cba.colorWriteMask = 0xF;
    if (ui) {
        cba.blendEnable = VK_TRUE;
        cba.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
        cba.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
        cba.colorBlendOp = VK_BLEND_OP_ADD;
        cba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
        cba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
        cba.alphaBlendOp = VK_BLEND_OP_ADD;
    }
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1;
    cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dsi{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dsi.dynamicStateCount = 2;
    dsi.pDynamicStates = dyn;

    VkGraphicsPipelineCreateInfo gp{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gp.stageCount = 2;
    gp.pStages = st;
    gp.pVertexInputState = &vin;
    gp.pInputAssemblyState = &ia;
    gp.pViewportState = &vp;
    gp.pRasterizationState = &rs;
    gp.pMultisampleState = &ms;
    gp.pDepthStencilState = &ds;
    gp.pColorBlendState = &cb;
    gp.pDynamicState = &dsi;
    gp.layout = ui ? g.uiLayout : g.pipeLayout;
    gp.renderPass = g.rp;
    gp.subpass = 0;
    VkPipeline pipe;
    VK_CHECK(vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &gp, nullptr, &pipe));
    vkDestroyShaderModule(g.dev, vsm, nullptr);
    vkDestroyShaderModule(g.dev, fsm, nullptr);
    return pipe;
}

static void createSwapchainStuff() {
    VkSurfaceCapabilitiesKHR caps;
    VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g.phys, g.surface, &caps));
    uint32_t fn = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surface, &fn, nullptr);
    std::vector<VkSurfaceFormatKHR> fmts(fn);
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surface, &fn, fmts.data());
    VkSurfaceFormatKHR chosen = fmts[0];
    for (auto& f : fmts)
        if (f.format == VK_FORMAT_R8G8B8A8_SRGB || f.format == VK_FORMAT_B8G8R8A8_SRGB) { chosen = f; break; }
    g.colorFormat = chosen.format;

    g.extent = caps.currentExtent;
    if (g.extent.width == 0xFFFFFFFFu) {
        g.extent.width = (uint32_t)ANativeWindow_getWidth(g.app->window);
        g.extent.height = (uint32_t)ANativeWindow_getHeight(g.app->window);
    }
    uint32_t imageCount = caps.minImageCount + 1;
    if (caps.maxImageCount > 0) imageCount = std::min(imageCount, caps.maxImageCount);
    VkCompositeAlphaFlagBitsKHR alpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    if (!(caps.supportedCompositeAlpha & alpha)) alpha = VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;

    VkSwapchainCreateInfoKHR sci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    sci.surface = g.surface;
    sci.minImageCount = imageCount;
    sci.imageFormat = chosen.format;
    sci.imageColorSpace = chosen.colorSpace;
    sci.imageExtent = g.extent;
    sci.imageArrayLayers = 1;
    sci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    sci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    sci.preTransform = (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR)
                           ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR : caps.currentTransform;
    sci.compositeAlpha = alpha;
    sci.presentMode = VK_PRESENT_MODE_FIFO_KHR;
    sci.clipped = VK_TRUE;
    VK_CHECK(vkCreateSwapchainKHR(g.dev, &sci, nullptr, &g.swapchain));
    uint32_t in = 0;
    vkGetSwapchainImagesKHR(g.dev, g.swapchain, &in, nullptr);
    g.images.resize(in);
    vkGetSwapchainImagesKHR(g.dev, g.swapchain, &in, g.images.data());

    VkImageCreateInfo di{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    di.imageType = VK_IMAGE_TYPE_2D;
    di.format = VK_FORMAT_D32_SFLOAT;
    di.extent = {g.extent.width, g.extent.height, 1};
    di.mipLevels = 1;
    di.arrayLayers = 1;
    di.samples = VK_SAMPLE_COUNT_1_BIT;
    di.tiling = VK_IMAGE_TILING_OPTIMAL;
    di.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    di.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VK_CHECK(vkCreateImage(g.dev, &di, nullptr, &g.depthImg));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(g.dev, g.depthImg, &mr);
    VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    mai.allocationSize = mr.size;
    mai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VK_CHECK(vkAllocateMemory(g.dev, &mai, nullptr, &g.depthMem));
    VK_CHECK(vkBindImageMemory(g.dev, g.depthImg, g.depthMem, 0));
    VkImageViewCreateInfo dvi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    dvi.image = g.depthImg;
    dvi.viewType = VK_IMAGE_VIEW_TYPE_2D;
    dvi.format = VK_FORMAT_D32_SFLOAT;
    dvi.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
    VK_CHECK(vkCreateImageView(g.dev, &dvi, nullptr, &g.depthView));

    VkAttachmentDescription at[2]{};
    at[0].format = g.colorFormat;
    at[0].samples = VK_SAMPLE_COUNT_1_BIT;
    at[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    at[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    at[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    at[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[0].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    at[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    at[1].format = VK_FORMAT_D32_SFLOAT;
    at[1].samples = VK_SAMPLE_COUNT_1_BIT;
    at[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    at[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;  // saves bandwidth on tiled GPUs
    at[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    at[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    at[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    VkAttachmentReference cref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkAttachmentReference dref{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sp{};
    sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sp.colorAttachmentCount = 1;
    sp.pColorAttachments = &cref;
    sp.pDepthStencilAttachment = &dref;
    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL;
    dep.dstSubpass = 0;
    dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dep.dstStageMask = dep.srcStageMask;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    VkRenderPassCreateInfo rci{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    rci.attachmentCount = 2;
    rci.pAttachments = at;
    rci.subpassCount = 1;
    rci.pSubpasses = &sp;
    rci.dependencyCount = 1;
    rci.pDependencies = &dep;
    VK_CHECK(vkCreateRenderPass(g.dev, &rci, nullptr, &g.rp));

    for (auto img : g.images) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = img;
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format = g.colorFormat;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VkImageView v;
        VK_CHECK(vkCreateImageView(g.dev, &vi, nullptr, &v));
        g.views.push_back(v);
        VkImageView att[2] = {v, g.depthView};
        VkFramebufferCreateInfo fci{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fci.renderPass = g.rp;
        fci.attachmentCount = 2;
        fci.pAttachments = att;
        fci.width = g.extent.width;
        fci.height = g.extent.height;
        fci.layers = 1;
        VkFramebuffer fb;
        VK_CHECK(vkCreateFramebuffer(g.dev, &fci, nullptr, &fb));
        g.fbs.push_back(fb);
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VkSemaphore s;
        VK_CHECK(vkCreateSemaphore(g.dev, &si, nullptr, &s));
        g.renderDone.push_back(s);
    }
    g.pipeline = createPipeline(false);
    g.uiPipeline = createPipeline(true);
    LOG("Swapchain %ux%u, %zu images", g.extent.width, g.extent.height, g.images.size());
}

static void recreateSwapchain() {
    destroySwapchainStuff();
    createSwapchainStuff();
    g.needRecreate = false;
}

// ------------------------------------------------------------------ HUD (debug text)
static void uiRect(UiVert*& out, float x0, float y0, float x1, float y1, float r, float gg, float b, float a) {
    if (g.uiCount + 6 > kUiMaxVerts) return;
    float W = (float)g.extent.width, H = (float)g.extent.height;
    float ax = x0 / W * 2 - 1, ay = y0 / H * 2 - 1, bx = x1 / W * 2 - 1, by = y1 / H * 2 - 1;
    UiVert q[6] = {{ax, ay, r, gg, b, a}, {bx, ay, r, gg, b, a}, {bx, by, r, gg, b, a},
                   {ax, ay, r, gg, b, a}, {bx, by, r, gg, b, a}, {ax, by, r, gg, b, a}};
    memcpy(out, q, sizeof(q));
    out += 6;
    g.uiCount += 6;
}

static void uiText(UiVert*& out, float x, float y, float s, const std::string& txt, float r, float gg, float b) {
    for (size_t i = 0; i < txt.size(); i++) {
        unsigned char ch = (unsigned char)txt[i];
        if (ch >= 0x80) {                       // UTF-8: draw one '?' per character
            if ((ch & 0xC0) == 0x80) continue;  // continuation byte
            ch = '?';
        }
        if (ch < 32 || ch > 126) ch = '?';
        const uint8_t* gl = &kFont[(ch - 32) * 5];
        for (int c = 0; c < 5; c++) {
            int row = 0;
            while (row < 7) {
                if (!((gl[c] >> row) & 1)) { row++; continue; }
                int r0 = row;
                while (row < 7 && ((gl[c] >> row) & 1)) row++;
                uiRect(out, x + c * s, y + r0 * s, x + (c + 1) * s, y + row * s, r, gg, b, 1.f);
            }
        }
        x += 6 * s;
    }
}

static std::string clip(const std::string& s, size_t maxChars) {
    // count characters (not bytes) so UTF-8 is not cut in the middle
    size_t chars = 0, i = 0;
    while (i < s.size()) {
        if (((unsigned char)s[i] & 0xC0) != 0x80) {
            if (chars == maxChars) break;
            chars++;
        }
        i++;
    }
    return s.substr(0, i);
}

static void buildHud(UiVert* out) {
    g.uiCount = 0;
    float W = (float)g.extent.width, H = (float)g.extent.height;
    float s = std::max(2.f, std::floor(H / 270.f + 0.5f));
    float lineH = 9 * s, x = W * 0.05f, y = H * 0.02f;
    size_t maxChars = (size_t)std::max(10.f, (W - 2 * x) / (6 * s));
    struct L { std::string t; float r, g, b; };
    std::vector<L> lines;
    char buf[96];
    snprintf(buf, sizeof buf, "FPS %.0f   nodes %zu", g.fps, g.scene.order.size());
    lines.push_back({buf, 0.5f, 1.f, 0.5f});
    if (!g.sceneOk) {
        std::string e = "SCENE ERROR " + g.sceneErr;
        for (int i = 0; i < 4 && !e.empty(); i++) {
            std::string part = clip(e, maxChars);
            lines.push_back({part, 1.f, 0.35f, 0.35f});
            e = e.substr(part.size());
        }
    }
    size_t ne = g.scene.errors.size();
    for (size_t i = ne > 3 ? ne - 3 : 0; i < ne; i++) lines.push_back({clip(g.scene.errors[i], maxChars), 1.f, 0.4f, 0.4f});
    for (auto& l : g.logLines) lines.push_back({clip(l, maxChars), 0.85f, 0.9f, 1.f});
    float boxW = 0;
    for (auto& l : lines) boxW = std::max(boxW, (float)l.t.size() * 6 * s);
    uiRect(out, x - 4 * s, y - 2 * s, x + boxW + 4 * s, y + lineH * lines.size() + 2 * s, 0.f, 0.f, 0.f, 0.45f);
    for (auto& l : lines) {
        uiText(out, x, y, s, l.t, l.r, l.g, l.b);
        y += lineH;
    }
}

// ------------------------------------------------------------------ scene rendering
template <class F>
static void walk(gino::Node* n, const Mat4& pw, F& fn) {
    if (!n->visible) return;
    Mat4 W = mul(pw, localMatrix(n));
    fn(n, W);
    for (auto& k : n->kids) walk(k.get(), W, fn);
}

static void recordFrame(VkCommandBuffer cb, uint32_t imageIndex, int f) {
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    VK_CHECK(vkBeginCommandBuffer(cb, &bi));

    // gather camera + light
    bool hasCam = false, hasLight = false;
    Mat4 camW = identity(), lightW = identity();
    float fov = 60.f;
    gino::Node* lightNode = nullptr;
    if (g.sceneOk && g.scene.root) {
        auto gather = [&](gino::Node* n, const Mat4& W) {
            if (n->type == gino::NT::Camera && !hasCam) { hasCam = true; camW = W; fov = n->fov; }
            if (n->type == gino::NT::Light && !hasLight) { hasLight = true; lightW = W; lightNode = n; }
        };
        walk(g.scene.root.get(), identity(), gather);
    }
    float aspect = (float)g.extent.width / (float)g.extent.height;
    Mat4 proj = perspective(fov * kDeg, aspect, 0.1f, 200.f);
    Mat4 view;
    Vec3 eye{0, 1.5f, 4.f};
    if (hasCam) { view = viewFromWorld(camW); eye = {camW.m[12], camW.m[13], camW.m[14]}; }
    else view = lookAt(eye, {0, 0, 0}, {0, 1, 0});
    Mat4 vpm = mul(proj, view);

    SceneUbo* u = g.uboPtr[f];
    Vec3 L = norm({0.5f, 1.f, 0.6f});
    float lc[3] = {1.f, 0.96f, 0.9f};
    if (hasLight && lightNode) {
        L = norm({lightW.m[8], lightW.m[9], lightW.m[10]});
        for (int i = 0; i < 3; i++) lc[i] = std::pow((&lightNode->col.x)[i], 2.2f) * lightNode->energy;
    }
    u->lightDir[0] = L.x; u->lightDir[1] = L.y; u->lightDir[2] = L.z; u->lightDir[3] = 0;
    u->lightColor[0] = lc[0]; u->lightColor[1] = lc[1]; u->lightColor[2] = lc[2]; u->lightColor[3] = 1;
    u->ambient[0] = 0.10f; u->ambient[1] = 0.12f; u->ambient[2] = 0.18f; u->ambient[3] = 1;
    u->camPos[0] = eye.x; u->camPos[1] = eye.y; u->camPos[2] = eye.z; u->camPos[3] = 1;

    VkClearValue clears[2];
    clears[0].color = {{0.04f, 0.06f, 0.12f, 1.f}};
    if (!g.sceneOk) clears[0].color = {{0.25f, 0.02f, 0.02f, 1.f}};
    clears[1].depthStencil = {1.f, 0};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rb.renderPass = g.rp;
    rb.framebuffer = g.fbs[imageIndex];
    rb.renderArea = {{0, 0}, g.extent};
    rb.clearValueCount = 2;
    rb.pClearValues = clears;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vp{0, 0, (float)g.extent.width, (float)g.extent.height, 0.f, 1.f};
    VkRect2D sc{{0, 0}, g.extent};
    vkCmdSetViewport(cb, 0, 1, &vp);
    vkCmdSetScissor(cb, 0, 1, &sc);

    if (g.sceneOk && g.scene.root) {
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pipeline);
        vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pipeLayout, 0, 1, &g.sets[f], 0, nullptr);
        VkDeviceSize off = 0;
        vkCmdBindVertexBuffers(cb, 0, 1, &g.vbuf, &off);
        vkCmdBindIndexBuffer(cb, g.ibuf, 0, VK_INDEX_TYPE_UINT16);
        auto draw = [&](gino::Node* n, const Mat4& W) {
            const MeshRange* r = nullptr;
            if (n->type == gino::NT::Cube) r = &g.meshes.cube;
            else if (n->type == gino::NT::Sphere) r = &g.meshes.sphere;
            else if (n->type == gino::NT::Plane) r = &g.meshes.plane;
            if (!r) return;
            PushData pd;
            Mat4 mvp = mul(vpm, W);
            memcpy(pd.mvp, mvp.m, sizeof(pd.mvp));
            const float* w = W.m;
            float m0[4] = {w[0], w[4], w[8], w[12]}, m1[4] = {w[1], w[5], w[9], w[13]}, m2[4] = {w[2], w[6], w[10], w[14]};
            memcpy(pd.m0, m0, 16); memcpy(pd.m1, m1, 16); memcpy(pd.m2, m2, 16);
            pd.color[0] = n->col.x; pd.color[1] = n->col.y; pd.color[2] = n->col.z; pd.color[3] = 1.f;
            vkCmdPushConstants(cb, g.pipeLayout, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(pd), &pd);
            vkCmdDrawIndexed(cb, r->count, 1, r->first, 0, 0);
        };
        walk(g.scene.root.get(), identity(), draw);
    }

    // HUD on top
    buildHud(g.uiPtr[f]);
    if (g.uiCount > 0) {
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.uiPipeline);
        VkDeviceSize off = 0;
        vkCmdBindVertexBuffers(cb, 0, 1, &g.uiBuf[f], &off);
        vkCmdDraw(cb, g.uiCount, 1, 0, 0);
    }
    vkCmdEndRenderPass(cb);
    VK_CHECK(vkEndCommandBuffer(cb));
}

static void drawFrame() {
    auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - g.last).count();
    g.last = now;
    g.fpsTimer += dt;
    g.fpsFrames++;
    if (g.fpsTimer >= 0.5f) {
        g.fps = g.fpsFrames / g.fpsTimer;
        g.fpsTimer = 0;
        g.fpsFrames = 0;
    }
    if (g.sceneOk) g.scene.update(std::min(dt, 0.1f));

    int f = g.frame;
    vkWaitForFences(g.dev, 1, &g.fence[f], VK_TRUE, UINT64_MAX);
    uint32_t idx;
    VkResult r = vkAcquireNextImageKHR(g.dev, g.swapchain, UINT64_MAX, g.imgAvail[f], VK_NULL_HANDLE, &idx);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) { recreateSwapchain(); return; }
    if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) { LOG("acquire failed %d", (int)r); return; }
    vkResetFences(g.dev, 1, &g.fence[f]);
    vkResetCommandBuffer(g.cmd[f], 0);
    recordFrame(g.cmd[f], idx, f);

    VkPipelineStageFlags wait = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.waitSemaphoreCount = 1;
    si.pWaitSemaphores = &g.imgAvail[f];
    si.pWaitDstStageMask = &wait;
    si.commandBufferCount = 1;
    si.pCommandBuffers = &g.cmd[f];
    si.signalSemaphoreCount = 1;
    si.pSignalSemaphores = &g.renderDone[idx];
    VK_CHECK(vkQueueSubmit(g.queue, 1, &si, g.fence[f]));

    VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
    pi.waitSemaphoreCount = 1;
    pi.pWaitSemaphores = &g.renderDone[idx];
    pi.swapchainCount = 1;
    pi.pSwapchains = &g.swapchain;
    pi.pImageIndices = &idx;
    r = vkQueuePresentKHR(g.queue, &pi);
    // VK_SUBOPTIMAL_KHR is normal on Android with a rotated display; only OUT_OF_DATE recreates.
    if (r == VK_ERROR_OUT_OF_DATE_KHR || g.needRecreate) recreateSwapchain();
    g.frame = (g.frame + 1) % kFrames;
}

// ------------------------------------------------------------------ android glue
static std::string readAsset(const char* name) {
    AAsset* a = AAssetManager_open(g.app->activity->assetManager, name, AASSET_MODE_BUFFER);
    if (!a) return "";
    size_t n = (size_t)AAsset_getLength(a);
    std::string s(n, '\0');
    AAsset_read(a, &s[0], n);
    AAsset_close(a);
    return s;
}

static void loadScene() {
    std::string src = readAsset("main.gino");
    if (src.empty()) { g.sceneOk = false; g.sceneErr = "main.gino not found in assets"; return; }
    g.scene.printSink = [](const std::string& m) {
        LOG("print: %s", m.c_str());
        g.logLines.push_back(m);
        while (g.logLines.size() > 6) g.logLines.pop_front();
    };
    g.sceneOk = g.scene.load(src, g.sceneErr);
    if (g.sceneOk) g.scene.start();
    else LOG("scene error: %s", g.sceneErr.c_str());
}

static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) {
                if (!g.instance) createInstance();
                createSurface();
                if (!g.dev) createDeviceAndResources();
                createSwapchainStuff();
                g.last = std::chrono::steady_clock::now();
                g.ready = true;
            }
            break;
        case APP_CMD_TERM_WINDOW:
            g.ready = false;
            destroySwapchainStuff();
            if (g.surface) { vkDestroySurfaceKHR(g.instance, g.surface, nullptr); g.surface = VK_NULL_HANDLE; }
            break;
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            g.needRecreate = true;
            break;
        default: break;
    }
}

static int32_t onInput(android_app*, AInputEvent* ev) {
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;
    int32_t action = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
    float x = AMotionEvent_getX(ev, 0), y = AMotionEvent_getY(ev, 0);
    float W = g.extent.width ? (float)g.extent.width : 1.f, H = g.extent.height ? (float)g.extent.height : 1.f;
    if (action == AMOTION_EVENT_ACTION_DOWN) {
        g.dragging = true;
        if (g.sceneOk) g.scene.tap(x / W, y / H);
    } else if (action == AMOTION_EVENT_ACTION_MOVE && g.dragging) {
        if (g.sceneOk) g.scene.drag((x - g.lastX) / H, (y - g.lastY) / H);
    } else if (action == AMOTION_EVENT_ACTION_UP || action == AMOTION_EVENT_ACTION_CANCEL) {
        g.dragging = false;
    }
    g.lastX = x;
    g.lastY = y;
    return 1;
}

void android_main(android_app* app) {
    g.app = app;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;
    loadScene();
    while (!app->destroyRequested) {
        int events;
        android_poll_source* src;
        while (ALooper_pollOnce(g.ready ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) break;
        }
        if (g.ready && !app->destroyRequested) drawFrame();
    }
    destroySwapchainStuff();
}
