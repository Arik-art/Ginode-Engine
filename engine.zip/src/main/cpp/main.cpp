// Mini 3D engine, stage 1: Vulkan on Android (NativeActivity).
// Rotating cube + floor, Lambert/Blinn-Phong light, touch-drag rotation.
#include <android_native_app_glue.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/input.h>
#include <vulkan/vulkan.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "shaders.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "Engine", __VA_ARGS__)
#define VK_CHECK(x)                                                              \
    do {                                                                         \
        VkResult r_ = (x);                                                       \
        if (r_ != VK_SUCCESS) {                                                  \
            LOG("Vulkan error %d at %s:%d", (int)r_, __FILE__, __LINE__);        \
            abort();                                                             \
        }                                                                        \
    } while (0)

// ------------------------------------------------------------------ math
struct Vec3 { float x, y, z; };
struct Mat4 { float m[16]; };  // column-major

static Vec3 sub(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static float dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static Vec3 cross(Vec3 a, Vec3 b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
static Vec3 norm(Vec3 a) {
    float l = std::sqrt(dot(a, a));
    return {a.x / l, a.y / l, a.z / l};
}
static Mat4 identity() {
    Mat4 r{};
    r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.f;
    return r;
}
static Mat4 mul(const Mat4& a, const Mat4& b) {
    Mat4 r{};
    for (int c = 0; c < 4; c++)
        for (int row = 0; row < 4; row++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + row] * b.m[c * 4 + k];
            r.m[c * 4 + row] = s;
        }
    return r;
}
static Mat4 rotY(float a) {
    Mat4 r = identity();
    float c = std::cos(a), s = std::sin(a);
    r.m[0] = c; r.m[2] = -s; r.m[8] = s; r.m[10] = c;
    return r;
}
static Mat4 rotX(float a) {
    Mat4 r = identity();
    float c = std::cos(a), s = std::sin(a);
    r.m[5] = c; r.m[6] = s; r.m[9] = -s; r.m[10] = c;
    return r;
}
// Right-handed, depth 0..1, Y flipped for Vulkan.
static Mat4 perspective(float fovy, float aspect, float n, float f) {
    float t = 1.f / std::tan(fovy * 0.5f);
    Mat4 r{};
    r.m[0] = t / aspect;
    r.m[5] = -t;
    r.m[10] = f / (n - f);
    r.m[11] = -1.f;
    r.m[14] = n * f / (n - f);
    return r;
}
static Mat4 lookAt(Vec3 eye, Vec3 center, Vec3 up) {
    Vec3 f = norm(sub(center, eye));
    Vec3 s = norm(cross(f, up));
    Vec3 u = cross(s, f);
    Mat4 r = identity();
    r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
    r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
    r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
    r.m[12] = -dot(s, eye);
    r.m[13] = -dot(u, eye);
    r.m[14] = dot(f, eye);
    return r;
}

// ------------------------------------------------------------------ mesh
struct Vertex { float pos[3]; float nrm[3]; float col[3]; };

static void addFace(std::vector<Vertex>& vs, std::vector<uint16_t>& is, Vec3 n, Vec3 u,
                    Vec3 v, Vec3 center, float half, Vec3 col) {
    uint16_t base = (uint16_t)vs.size();
    const float su[4] = {-1, 1, 1, -1};
    const float sv[4] = {-1, -1, 1, 1};
    for (int i = 0; i < 4; i++) {
        Vertex x;
        x.pos[0] = center.x + (n.x + u.x * su[i] + v.x * sv[i]) * half;
        x.pos[1] = center.y + (n.y + u.y * su[i] + v.y * sv[i]) * half;
        x.pos[2] = center.z + (n.z + u.z * su[i] + v.z * sv[i]) * half;
        x.nrm[0] = n.x; x.nrm[1] = n.y; x.nrm[2] = n.z;
        x.col[0] = col.x; x.col[1] = col.y; x.col[2] = col.z;
        vs.push_back(x);
    }
    const uint16_t idx[6] = {0, 1, 2, 0, 2, 3};
    for (uint16_t i : idx) is.push_back(base + i);
}

// ------------------------------------------------------------------ engine state
static const int kFrames = 2;

struct Engine {
    android_app* app = nullptr;
    bool ready = false;
    bool needRecreate = false;

    // persistent
    VkInstance instance = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice dev = VK_NULL_HANDLE;
    uint32_t qfam = 0;
    VkQueue queue = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE;
    VkCommandBuffer cmd[kFrames] = {};
    VkSemaphore imgAvail[kFrames] = {};
    VkFence fence[kFrames] = {};
    VkPipelineLayout pipeLayout = VK_NULL_HANDLE;
    VkBuffer vbuf = VK_NULL_HANDLE, ibuf = VK_NULL_HANDLE;
    VkDeviceMemory vmem = VK_NULL_HANDLE, imem = VK_NULL_HANDLE;
    uint32_t cubeIndexCount = 0, floorIndexCount = 0, floorFirstIndex = 0;
    int frame = 0;

    // per surface
    VkSurfaceKHR surface = VK_NULL_HANDLE;
    VkSwapchainKHR swapchain = VK_NULL_HANDLE;
    VkFormat colorFormat = VK_FORMAT_UNDEFINED;
    VkExtent2D extent{};
    std::vector<VkImage> images;
    std::vector<VkImageView> views;
    std::vector<VkFramebuffer> fbs;
    std::vector<VkSemaphore> renderDone;
    VkImage depthImg = VK_NULL_HANDLE;
    VkDeviceMemory depthMem = VK_NULL_HANDLE;
    VkImageView depthView = VK_NULL_HANDLE;
    VkRenderPass rp = VK_NULL_HANDLE;
    VkPipeline pipeline = VK_NULL_HANDLE;

    // scene
    float yaw = 0.4f, pitch = 0.3f;
    float lastX = 0, lastY = 0;
    bool dragging = false;
    std::chrono::steady_clock::time_point last;
    float fpsTimer = 0;
    int fpsFrames = 0;
};
static Engine g;

// ------------------------------------------------------------------ vulkan helpers
static uint32_t findMem(uint32_t bits, VkMemoryPropertyFlags want) {
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(g.phys, &mp);
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & want) == want) return i;
    LOG("no memory type");
    abort();
}

static void makeBuffer(const void* data, VkDeviceSize size, VkBufferUsageFlags usage,
                       VkBuffer& buf, VkDeviceMemory& mem) {
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size;
    bi.usage = usage;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VK_CHECK(vkCreateBuffer(g.dev, &bi, nullptr, &buf));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(g.dev, buf, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
                                                        VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    VK_CHECK(vkAllocateMemory(g.dev, &ai, nullptr, &mem));
    VK_CHECK(vkBindBufferMemory(g.dev, buf, mem, 0));
    void* p;
    VK_CHECK(vkMapMemory(g.dev, mem, 0, size, 0, &p));
    memcpy(p, data, (size_t)size);
    vkUnmapMemory(g.dev, mem);
}

static VkShaderModule makeShader(const uint32_t* code, size_t bytes) {
    VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    ci.codeSize = bytes;
    ci.pCode = code;
    VkShaderModule m;
    VK_CHECK(vkCreateShaderModule(g.dev, &ci, nullptr, &m));
    return m;
}

// ------------------------------------------------------------------ init (once)
static void createInstance() {
    const char* exts[] = {"VK_KHR_surface", "VK_KHR_android_surface"};
    VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.pApplicationName = "Engine";
    ai.apiVersion = VK_API_VERSION_1_0;
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &ai;
    ci.enabledExtensionCount = 2;
    ci.ppEnabledExtensionNames = exts;
    VK_CHECK(vkCreateInstance(&ci, nullptr, &g.instance));
}

static void createSurface() {
    VkAndroidSurfaceCreateInfoKHR ci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    ci.window = g.app->window;
    VK_CHECK(vkCreateAndroidSurfaceKHR(g.instance, &ci, nullptr, &g.surface));
}

static void createDeviceAndMesh() {
    uint32_t n = 0;
    vkEnumeratePhysicalDevices(g.instance, &n, nullptr);
    std::vector<VkPhysicalDevice> pds(n);
    vkEnumeratePhysicalDevices(g.instance, &n, pds.data());
    g.phys = VK_NULL_HANDLE;
    for (auto pd : pds) {
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qs(qn);
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, qs.data());
        for (uint32_t i = 0; i < qn; i++) {
            VkBool32 present = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, g.surface, &present);
            if ((qs[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && present) {
                g.phys = pd;
                g.qfam = i;
                break;
            }
        }
        if (g.phys) break;
    }
    if (!g.phys) { LOG("no suitable GPU"); abort(); }

    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(g.phys, &props);
    LOG("GPU: %s", props.deviceName);

    float prio = 1.f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = g.qfam;
    qci.queueCount = 1;
    qci.pQueuePriorities = &prio;
    const char* dexts[] = {"VK_KHR_swapchain"};
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1;
    dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = 1;
    dci.ppEnabledExtensionNames = dexts;
    VK_CHECK(vkCreateDevice(g.phys, &dci, nullptr, &g.dev));
    vkGetDeviceQueue(g.dev, g.qfam, 0, &g.queue);

    VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    pci.queueFamilyIndex = g.qfam;
    VK_CHECK(vkCreateCommandPool(g.dev, &pci, nullptr, &g.pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = g.pool;
    cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cai.commandBufferCount = kFrames;
    VK_CHECK(vkAllocateCommandBuffers(g.dev, &cai, g.cmd));
    for (int i = 0; i < kFrames; i++) {
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VK_CHECK(vkCreateSemaphore(g.dev, &si, nullptr, &g.imgAvail[i]));
        VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        VK_CHECK(vkCreateFence(g.dev, &fi, nullptr, &g.fence[i]));
    }

    VkPushConstantRange pcr{VK_SHADER_STAGE_VERTEX_BIT, 0, 128};
    VkPipelineLayoutCreateInfo lci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    lci.pushConstantRangeCount = 1;
    lci.pPushConstantRanges = &pcr;
    VK_CHECK(vkCreatePipelineLayout(g.dev, &lci, nullptr, &g.pipeLayout));

    // Geometry: cube (indices 0..35) + floor (36..41)
    std::vector<Vertex> vs;
    std::vector<uint16_t> is;
    const float h = 0.5f;
    addFace(vs, is, {1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, 0}, h, {0.90f, 0.25f, 0.20f});
    addFace(vs, is, {-1, 0, 0}, {0, 0, 1}, {0, 1, 0}, {0, 0, 0}, h, {0.20f, 0.70f, 0.30f});
    addFace(vs, is, {0, 1, 0}, {0, 0, 1}, {1, 0, 0}, {0, 0, 0}, h, {0.25f, 0.45f, 0.95f});
    addFace(vs, is, {0, -1, 0}, {1, 0, 0}, {0, 0, 1}, {0, 0, 0}, h, {0.95f, 0.80f, 0.20f});
    addFace(vs, is, {0, 0, 1}, {1, 0, 0}, {0, 1, 0}, {0, 0, 0}, h, {0.80f, 0.30f, 0.80f});
    addFace(vs, is, {0, 0, -1}, {0, 1, 0}, {1, 0, 0}, {0, 0, 0}, h, {0.20f, 0.80f, 0.85f});
    g.cubeIndexCount = (uint32_t)is.size();
    g.floorFirstIndex = g.cubeIndexCount;
    // floor: the +Y face scaled up, 'center' lowered
    {
        Vec3 n{0, 1, 0};
        uint16_t base = (uint16_t)vs.size();
        const float s = 6.f, y = -1.2f;
        const float px[4] = {-s, s, s, -s};
        const float pz[4] = {s, s, -s, -s};  // CCW seen from above
        for (int i = 0; i < 4; i++) {
            Vertex x{{px[i], y, pz[i]}, {n.x, n.y, n.z}, {0.35f, 0.36f, 0.38f}};
            vs.push_back(x);
        }
        const uint16_t idx[6] = {0, 1, 2, 0, 2, 3};
        for (uint16_t i : idx) is.push_back(base + i);
    }
    g.floorIndexCount = 6;
    makeBuffer(vs.data(), vs.size() * sizeof(Vertex), VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
               g.vbuf, g.vmem);
    makeBuffer(is.data(), is.size() * sizeof(uint16_t), VK_BUFFER_USAGE_INDEX_BUFFER_BIT,
               g.ibuf, g.imem);
}

// ------------------------------------------------------------------ swapchain-dependent
static void destroySwapchainStuff() {
    if (!g.dev) return;
    vkDeviceWaitIdle(g.dev);
    if (g.pipeline) vkDestroyPipeline(g.dev, g.pipeline, nullptr);
    if (g.rp) vkDestroyRenderPass(g.dev, g.rp, nullptr);
    for (auto f : g.fbs) vkDestroyFramebuffer(g.dev, f, nullptr);
    for (auto v : g.views) vkDestroyImageView(g.dev, v, nullptr);
    for (auto s : g.renderDone) vkDestroySemaphore(g.dev, s, nullptr);
    if (g.depthView) vkDestroyImageView(g.dev, g.depthView, nullptr);
    if (g.depthImg) vkDestroyImage(g.dev, g.depthImg, nullptr);
    if (g.depthMem) vkFreeMemory(g.dev, g.depthMem, nullptr);
    if (g.swapchain) vkDestroySwapchainKHR(g.dev, g.swapchain, nullptr);
    g.pipeline = VK_NULL_HANDLE; g.rp = VK_NULL_HANDLE;
    g.fbs.clear(); g.views.clear(); g.renderDone.clear(); g.images.clear();
    g.depthView = VK_NULL_HANDLE; g.depthImg = VK_NULL_HANDLE; g.depthMem = VK_NULL_HANDLE;
    g.swapchain = VK_NULL_HANDLE;
}

static void createSwapchainStuff() {
    VkSurfaceCapabilitiesKHR caps;
    VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g.phys, g.surface, &caps));

    uint32_t fn = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surface, &fn, nullptr);
    std::vector<VkSurfaceFormatKHR> fmts(fn);
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surface, &fn, fmts.data());
    VkSurfaceFormatKHR chosen = fmts[0];
    for (auto& f : fmts)
        if (f.format == VK_FORMAT_R8G8B8A8_SRGB || f.format == VK_FORMAT_B8G8R8A8_SRGB) {
            chosen = f;
            break;
        }
    g.colorFormat = chosen.format;

    g.extent = caps.currentExtent;
    if (g.extent.width == 0xFFFFFFFFu) {
        g.extent.width = (uint32_t)ANativeWindow_getWidth(g.app->window);
        g.extent.height = (uint32_t)ANativeWindow_getHeight(g.app->window);
    }

    uint32_t imageCount = caps.minImageCount + 1;
    if (caps.maxImageCount > 0) imageCount = std::min(imageCount, caps.maxImageCount);

    VkCompositeAlphaFlagBitsKHR alpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    if (!(caps.supportedCompositeAlpha & alpha)) alpha = VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;

    VkSwapchainCreateInfoKHR sci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    sci.surface = g.surface;
    sci.minImageCount = imageCount;
    sci.imageFormat = chosen.format;
    sci.imageColorSpace = chosen.colorSpace;
    sci.imageExtent = g.extent;
    sci.imageArrayLayers = 1;
    sci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    sci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    sci.preTransform = (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR)
                           ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR
                           : caps.currentTransform;
    sci.compositeAlpha = alpha;
    sci.presentMode = VK_PRESENT_MODE_FIFO_KHR;
    sci.clipped = VK_TRUE;
    VK_CHECK(vkCreateSwapchainKHR(g.dev, &sci, nullptr, &g.swapchain));

    uint32_t in = 0;
    vkGetSwapchainImagesKHR(g.dev, g.swapchain, &in, nullptr);
    g.images.resize(in);
    vkGetSwapchainImagesKHR(g.dev, g.swapchain, &in, g.images.data());

    // depth
    VkImageCreateInfo di{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    di.imageType = VK_IMAGE_TYPE_2D;
    di.format = VK_FORMAT_D32_SFLOAT;
    di.extent = {g.extent.width, g.extent.height, 1};
    di.mipLevels = 1;
    di.arrayLayers = 1;
    di.samples = VK_SAMPLE_COUNT_1_BIT;
    di.tiling = VK_IMAGE_TILING_OPTIMAL;
    di.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    di.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VK_CHECK(vkCreateImage(g.dev, &di, nullptr, &g.depthImg));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(g.dev, g.depthImg, &mr);
    VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    mai.allocationSize = mr.size;
    mai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VK_CHECK(vkAllocateMemory(g.dev, &mai, nullptr, &g.depthMem));
    VK_CHECK(vkBindImageMemory(g.dev, g.depthImg, g.depthMem, 0));
    VkImageViewCreateInfo dvi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    dvi.image = g.depthImg;
    dvi.viewType = VK_IMAGE_VIEW_TYPE_2D;
    dvi.format = VK_FORMAT_D32_SFLOAT;
    dvi.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
    VK_CHECK(vkCreateImageView(g.dev, &dvi, nullptr, &g.depthView));

    // render pass
    VkAttachmentDescription at[2]{};
    at[0].format = g.colorFormat;
    at[0].samples = VK_SAMPLE_COUNT_1_BIT;
    at[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    at[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    at[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    at[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[0].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    at[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    at[1].format = VK_FORMAT_D32_SFLOAT;
    at[1].samples = VK_SAMPLE_COUNT_1_BIT;
    at[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    at[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;  // saves bandwidth on tiled GPUs
    at[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    at[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    at[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    VkAttachmentReference cref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkAttachmentReference dref{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sp{};
    sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sp.colorAttachmentCount = 1;
    sp.pColorAttachments = &cref;
    sp.pDepthStencilAttachment = &dref;
    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL;
    dep.dstSubpass = 0;
    dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT |
                       VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dep.dstStageMask = dep.srcStageMask;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
                        VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    VkRenderPassCreateInfo rci{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    rci.attachmentCount = 2;
    rci.pAttachments = at;
    rci.subpassCount = 1;
    rci.pSubpasses = &sp;
    rci.dependencyCount = 1;
    rci.pDependencies = &dep;
    VK_CHECK(vkCreateRenderPass(g.dev, &rci, nullptr, &g.rp));

    // views, framebuffers, semaphores
    for (auto img : g.images) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = img;
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format = g.colorFormat;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VkImageView v;
        VK_CHECK(vkCreateImageView(g.dev, &vi, nullptr, &v));
        g.views.push_back(v);
        VkImageView att[2] = {v, g.depthView};
        VkFramebufferCreateInfo fci{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fci.renderPass = g.rp;
        fci.attachmentCount = 2;
        fci.pAttachments = att;
        fci.width = g.extent.width;
        fci.height = g.extent.height;
        fci.layers = 1;
        VkFramebuffer fb;
        VK_CHECK(vkCreateFramebuffer(g.dev, &fci, nullptr, &fb));
        g.fbs.push_back(fb);
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VkSemaphore s;
        VK_CHECK(vkCreateSemaphore(g.dev, &si, nullptr, &s));
        g.renderDone.push_back(s);
    }

    // pipeline
    VkShaderModule vsm = makeShader(kVertSpv, sizeof(kVertSpv));
    VkShaderModule fsm = makeShader(kFragSpv, sizeof(kFragSpv));
    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    st[0].module = vsm;
    st[0].pName = "main";
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    st[1].module = fsm;
    st[1].pName = "main";

    VkVertexInputBindingDescription bind{0, sizeof(Vertex), VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription attr[3] = {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex, pos)},
        {1, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex, nrm)},
        {2, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex, col)}};
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    vin.vertexBindingDescriptionCount = 1;
    vin.pVertexBindingDescriptions = &bind;
    vin.vertexAttributeDescriptionCount = 3;
    vin.pVertexAttributeDescriptions = attr;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1;
    vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    rs.cullMode = VK_CULL_MODE_BACK_BIT;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    ds.depthTestEnable = VK_TRUE;
    ds.depthWriteEnable = VK_TRUE;
    ds.depthCompareOp = VK_COMPARE_OP_LESS;
    VkPipelineColorBlendAttachmentState cba{};
    cba.colorWriteMask = 0xF;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1;
    cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dsi{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dsi.dynamicStateCount = 2;
    dsi.pDynamicStates = dyn;

    VkGraphicsPipelineCreateInfo gp{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gp.stageCount = 2;
    gp.pStages = st;
    gp.pVertexInputState = &vin;
    gp.pInputAssemblyState = &ia;
    gp.pViewportState = &vp;
    gp.pRasterizationState = &rs;
    gp.pMultisampleState = &ms;
    gp.pDepthStencilState = &ds;
    gp.pColorBlendState = &cb;
    gp.pDynamicState = &dsi;
    gp.layout = g.pipeLayout;
    gp.renderPass = g.rp;
    gp.subpass = 0;
    VK_CHECK(vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &gp, nullptr, &g.pipeline));
    vkDestroyShaderModule(g.dev, vsm, nullptr);
    vkDestroyShaderModule(g.dev, fsm, nullptr);

    LOG("Swapchain %ux%u, %zu images", g.extent.width, g.extent.height, g.images.size());
}

static void recreateSwapchain() {
    destroySwapchainStuff();
    createSwapchainStuff();
    g.needRecreate = false;
}

// ------------------------------------------------------------------ frame
struct PushData { Mat4 mvp; Mat4 model; };

static void recordFrame(VkCommandBuffer cb, uint32_t imageIndex, float time) {
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    VK_CHECK(vkBeginCommandBuffer(cb, &bi));

    VkClearValue clears[2];
    clears[0].color = {{0.02f, 0.03f, 0.06f, 1.f}};
    clears[1].depthStencil = {1.f, 0};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rb.renderPass = g.rp;
    rb.framebuffer = g.fbs[imageIndex];
    rb.renderArea = {{0, 0}, g.extent};
    rb.clearValueCount = 2;
    rb.pClearValues = clears;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pipeline);
    VkViewport vp{0, 0, (float)g.extent.width, (float)g.extent.height, 0.f, 1.f};
    VkRect2D sc{{0, 0}, g.extent};
    vkCmdSetViewport(cb, 0, 1, &vp);
    vkCmdSetScissor(cb, 0, 1, &sc);
    VkDeviceSize off = 0;
    vkCmdBindVertexBuffers(cb, 0, 1, &g.vbuf, &off);
    vkCmdBindIndexBuffer(cb, g.ibuf, 0, VK_INDEX_TYPE_UINT16);

    float aspect = (float)g.extent.width / (float)g.extent.height;
    Mat4 proj = perspective(1.0f, aspect, 0.1f, 50.f);
    Mat4 view = lookAt({0.f, 1.5f, 4.f}, {0.f, -0.2f, 0.f}, {0.f, 1.f, 0.f});
    Mat4 vpm = mul(proj, view);

    // floor
    PushData pd;
    pd.model = identity();
    pd.mvp = vpm;
    vkCmdPushConstants(cb, g.pipeLayout, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(pd), &pd);
    vkCmdDrawIndexed(cb, g.floorIndexCount, 1, g.floorFirstIndex, 0, 0);

    // cube
    pd.model = mul(rotY(g.yaw + time * 0.6f), rotX(g.pitch));
    pd.mvp = mul(vpm, pd.model);
    vkCmdPushConstants(cb, g.pipeLayout, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(pd), &pd);
    vkCmdDrawIndexed(cb, g.cubeIndexCount, 1, 0, 0, 0);

    vkCmdEndRenderPass(cb);
    VK_CHECK(vkEndCommandBuffer(cb));
}

static void drawFrame() {
    auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - g.last).count();
    g.last = now;
    static float t = 0.f;
    t += dt;
    g.fpsTimer += dt;
    g.fpsFrames++;
    if (g.fpsTimer >= 2.f) {
        LOG("FPS: %.1f", g.fpsFrames / g.fpsTimer);
        g.fpsTimer = 0;
        g.fpsFrames = 0;
    }

    int f = g.frame;
    vkWaitForFences(g.dev, 1, &g.fence[f], VK_TRUE, UINT64_MAX);
    uint32_t idx;
    VkResult r = vkAcquireNextImageKHR(g.dev, g.swapchain, UINT64_MAX, g.imgAvail[f],
                                       VK_NULL_HANDLE, &idx);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) { recreateSwapchain(); return; }
    if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) { LOG("acquire failed %d", (int)r); return; }
    vkResetFences(g.dev, 1, &g.fence[f]);
    vkResetCommandBuffer(g.cmd[f], 0);
    recordFrame(g.cmd[f], idx, t);

    VkPipelineStageFlags wait = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.waitSemaphoreCount = 1;
    si.pWaitSemaphores = &g.imgAvail[f];
    si.pWaitDstStageMask = &wait;
    si.commandBufferCount = 1;
    si.pCommandBuffers = &g.cmd[f];
    si.signalSemaphoreCount = 1;
    si.pSignalSemaphores = &g.renderDone[idx];
    VK_CHECK(vkQueueSubmit(g.queue, 1, &si, g.fence[f]));

    VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
    pi.waitSemaphoreCount = 1;
    pi.pWaitSemaphores = &g.renderDone[idx];
    pi.swapchainCount = 1;
    pi.pSwapchains = &g.swapchain;
    pi.pImageIndices = &idx;
    r = vkQueuePresentKHR(g.queue, &pi);
    // NOTE: VK_SUBOPTIMAL_KHR is expected on Android when the display is rotated
    // (no pre-rotation yet), so only OUT_OF_DATE triggers recreation.
    if (r == VK_ERROR_OUT_OF_DATE_KHR || g.needRecreate) recreateSwapchain();
    g.frame = (g.frame + 1) % kFrames;
}

// ------------------------------------------------------------------ android glue
static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) {
                if (!g.instance) createInstance();
                createSurface();
                if (!g.dev) createDeviceAndMesh();
                createSwapchainStuff();
                g.last = std::chrono::steady_clock::now();
                g.ready = true;
            }
            break;
        case APP_CMD_TERM_WINDOW:
            g.ready = false;
            destroySwapchainStuff();
            if (g.surface) {
                vkDestroySurfaceKHR(g.instance, g.surface, nullptr);
                g.surface = VK_NULL_HANDLE;
            }
            break;
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            g.needRecreate = true;
            break;
        default:
            break;
    }
}

static int32_t onInput(android_app*, AInputEvent* ev) {
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;
    int32_t action = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
    float x = AMotionEvent_getX(ev, 0), y = AMotionEvent_getY(ev, 0);
    if (action == AMOTION_EVENT_ACTION_DOWN) {
        g.dragging = true;
    } else if (action == AMOTION_EVENT_ACTION_MOVE && g.dragging) {
        g.yaw += (x - g.lastX) * 0.01f;
        g.pitch += (y - g.lastY) * 0.01f;
    } else if (action == AMOTION_EVENT_ACTION_UP || action == AMOTION_EVENT_ACTION_CANCEL) {
        g.dragging = false;
    }
    g.lastX = x;
    g.lastY = y;
    return 1;
}

void android_main(android_app* app) {
    g.app = app;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;
    while (!app->destroyRequested) {
        int events;
        android_poll_source* src;
        while (ALooper_pollOnce(g.ready ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) break;
        }
        if (g.ready && !app->destroyRequested) drawFrame();
    }
    destroySwapchainStuff();
}
