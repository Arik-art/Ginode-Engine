#include <android_native_app_glue.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/input.h>
#include <vulkan/vulkan.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

#include "shaders.h"
#include "ui_shaders.h"
#include "scene.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "NovaEngine", __VA_ARGS__)
#define VK_CHECK(x) do { VkResult r_ = (x); if (r_ != VK_SUCCESS) { LOG("VK err %d at %d", (int)r_, __LINE__); abort(); } } while (0)

static Vec3 vSub(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static float vDot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static Vec3 vCross(Vec3 a, Vec3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static Vec3 vNorm(Vec3 a) { float l = std::sqrt(vDot(a, a)); return l > 1e-6f ? Vec3{a.x / l, a.y / l, a.z / l} : Vec3{0, 1, 0}; }

static Mat4 perspective(float fovy, float aspect, float n, float f) {
    float t = 1.f / std::tan(fovy * 0.5f);
    Mat4 r{};
    r.m[0] = t / aspect;
    r.m[5] = -t;
    r.m[10] = f / (n - f);
    r.m[11] = -1.f;
    r.m[14] = n * f / (n - f);
    return r;
}

static Mat4 lookAt(Vec3 eye, Vec3 center, Vec3 up) {
    Vec3 f = vNorm(vSub(center, eye));
    Vec3 s = vNorm(vCross(f, up));
    Vec3 u = vCross(s, f);
    Mat4 r = matIdentity();
    r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
    r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
    r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
    r.m[12] = -vDot(s, eye);
    r.m[13] = -vDot(u, eye);
    r.m[14] = vDot(f, eye);
    return r;
}

// 5x7 Pixel Font
static const uint8_t* glyph5x7(char c) {
    if (c >= 'a' && c <= 'z') c = c - 'a' + 'A';
    static const uint8_t sp[5] = {0,0,0,0,0};
    switch (c) {
        case 'A': { static const uint8_t g[5]={0x7E,0x11,0x11,0x11,0x7E}; return g; }
        case 'B': { static const uint8_t g[5]={0x7F,0x49,0x49,0x49,0x36}; return g; }
        case 'C': { static const uint8_t g[5]={0x3E,0x41,0x41,0x41,0x22}; return g; }
        case 'D': { static const uint8_t g[5]={0x7F,0x41,0x41,0x22,0x1C}; return g; }
        case 'E': { static const uint8_t g[5]={0x7F,0x49,0x49,0x49,0x41}; return g; }
        case 'F': { static const uint8_t g[5]={0x7F,0x09,0x09,0x09,0x01}; return g; }
        case 'G': { static const uint8_t g[5]={0x3E,0x41,0x49,0x49,0x7A}; return g; }
        case 'H': { static const uint8_t g[5]={0x7F,0x08,0x08,0x08,0x7F}; return g; }
        case 'I': { static const uint8_t g[5]={0x00,0x41,0x7F,0x41,0x00}; return g; }
        case 'J': { static const uint8_t g[5]={0x20,0x40,0x41,0x3F,0x01}; return g; }
        case 'K': { static const uint8_t g[5]={0x7F,0x08,0x14,0x22,0x41}; return g; }
        case 'L': { static const uint8_t g[5]={0x7F,0x40,0x40,0x40,0x40}; return g; }
        case 'M': { static const uint8_t g[5]={0x7F,0x02,0x0C,0x02,0x7F}; return g; }
        case 'N': { static const uint8_t g[5]={0x7F,0x04,0x08,0x10,0x7F}; return g; }
        case 'O': { static const uint8_t g[5]={0x3E,0x41,0x41,0x41,0x3E}; return g; }
        case 'P': { static const uint8_t g[5]={0x7F,0x09,0x09,0x09,0x06}; return g; }
        case 'Q': { static const uint8_t g[5]={0x3E,0x41,0x51,0x21,0x5E}; return g; }
        case 'R': { static const uint8_t g[5]={0x7F,0x09,0x19,0x29,0x46}; return g; }
        case 'S': { static const uint8_t g[5]={0x46,0x49,0x49,0x49,0x31}; return g; }
        case 'T': { static const uint8_t g[5]={0x01,0x01,0x7F,0x01,0x01}; return g; }
        case 'U': { static const uint8_t g[5]={0x3F,0x40,0x40,0x40,0x3F}; return g; }
        case 'V': { static const uint8_t g[5]={0x1F,0x20,0x40,0x20,0x1F}; return g; }
        case 'W': { static const uint8_t g[5]={0x3F,0x40,0x38,0x40,0x3F}; return g; }
        case 'X': { static const uint8_t g[5]={0x63,0x14,0x08,0x14,0x63}; return g; }
        case 'Y': { static const uint8_t g[5]={0x07,0x08,0x70,0x08,0x07}; return g; }
        case 'Z': { static const uint8_t g[5]={0x61,0x51,0x49,0x45,0x43}; return g; }
        case '0': { static const uint8_t g[5]={0x3E,0x51,0x49,0x45,0x3E}; return g; }
        case '1': { static const uint8_t g[5]={0x00,0x42,0x7F,0x40,0x00}; return g; }
        case '2': { static const uint8_t g[5]={0x42,0x61,0x51,0x49,0x46}; return g; }
        case '3': { static const uint8_t g[5]={0x21,0x41,0x45,0x4B,0x31}; return g; }
        case '4': { static const uint8_t g[5]={0x18,0x14,0x12,0x7F,0x10}; return g; }
        case '5': { static const uint8_t g[5]={0x27,0x45,0x45,0x45,0x39}; return g; }
        case '6': { static const uint8_t g[5]={0x3C,0x4A,0x49,0x49,0x30}; return g; }
        case '7': { static const uint8_t g[5]={0x01,0x71,0x09,0x05,0x03}; return g; }
        case '8': { static const uint8_t g[5]={0x36,0x49,0x49,0x49,0x36}; return g; }
        case '9': { static const uint8_t g[5]={0x06,0x49,0x49,0x29,0x1E}; return g; }
        case '+': { static const uint8_t g[5]={0x08,0x08,0x3E,0x08,0x08}; return g; }
        case '-': { static const uint8_t g[5]={0x08,0x08,0x08,0x08,0x08}; return g; }
        case ':': { static const uint8_t g[5]={0x00,0x36,0x36,0x00,0x00}; return g; }
        case '.': { static const uint8_t g[5]={0x00,0x60,0x60,0x00,0x00}; return g; }
        case '>': { static const uint8_t g[5]={0x41,0x22,0x14,0x08,0x00}; return g; }
        case '/': { static const uint8_t g[5]={0x20,0x10,0x08,0x04,0x02}; return g; }
        default: return sp;
    }
}

struct Vertex3D { float pos[3]; float nrm[3]; float col[3]; };
struct Vertex2D { float pos[2]; float col[4]; };

struct UIButton {
    float x, y, w, h;
    std::string label;
    int actionId;
    int param;
    float r, g, b;
};

static const int kFrames = 2;
static const size_t kMaxUiVerts = 32768;

struct Engine {
    android_app* app = nullptr;
    bool ready = false;
    bool needRecreate = false;

    VkInstance instance = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice dev = VK_NULL_HANDLE;
    uint32_t qfam = 0;
    VkQueue queue = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE;
    VkCommandBuffer cmd[kFrames] = {};
    VkSemaphore imgAvail[kFrames] = {};
    VkFence fence[kFrames] = {};

    VkPipelineLayout pipeLayout3D = VK_NULL_HANDLE;
    VkPipelineLayout pipeLayoutUI = VK_NULL_HANDLE;
    VkBuffer vbuf = VK_NULL_HANDLE, ibuf = VK_NULL_HANDLE;
    VkDeviceMemory vmem = VK_NULL_HANDLE, imem = VK_NULL_HANDLE;
    uint32_t cubeIndexCount = 0, floorIndexCount = 0, floorFirstIndex = 0;

    VkBuffer uiVbuf[kFrames] = {};
    VkDeviceMemory uiVmem[kFrames] = {};
    void* uiMapped[kFrames] = {};
    std::vector<Vertex2D> uiVerts;
    std::vector<UIButton> buttons;

    int frame = 0;

    VkSurfaceKHR surface = VK_NULL_HANDLE;
    VkSwapchainKHR swapchain = VK_NULL_HANDLE;
    VkFormat colorFormat = VK_FORMAT_UNDEFINED;
    VkExtent2D extent{};
    std::vector<VkImage> images;
    std::vector<VkImageView> views;
    std::vector<VkFramebuffer> fbs;
    std::vector<VkSemaphore> renderDone;
    VkImage depthImg = VK_NULL_HANDLE;
    VkDeviceMemory depthMem = VK_NULL_HANDLE;
    VkImageView depthView = VK_NULL_HANDLE;
    VkRenderPass rp = VK_NULL_HANDLE;
    VkPipeline pipeline3D = VK_NULL_HANDLE;
    VkPipeline pipelineUI = VK_NULL_HANDLE;

    std::unique_ptr<SceneNode> root;
    SceneNode* selected = nullptr;
    int nextNodeId = 1;
    bool playing = true;

    float camYaw = 0.5f, camPitch = 0.35f, camDist = 6.5f;
    float lastX = 0, lastY = 0;
    float touchDx = 0, touchDy = 0;
    bool dragging = false;
    bool tapOccurred = false;
    std::chrono::steady_clock::time_point last;
    float totalTime = 0.f;
    float fps = 60.f, fpsTimer = 0.f;
    int fpsFrames = 0;
};
static Engine g;

// Default NovaScript scene using the exact Russian syntax!
static const char* kDefaultSceneScript =
    "нода Пол : Пол\n"
    "  старт\n"
    "    позиция.y = -0.5\n"
    "\n"
    "нода Игрок : Куб\n"
    "  скорость = 3\n"
    "  старт\n"
    "    позиция.y = 1\n"
    "  кадр\n"
    "    вращение.y += скорость * дт\n"
    "    если касание\n"
    "      скорость = -скорость\n"
    "  нода Спутник : Куб\n"
    "    старт\n"
    "      позиция.x = 1.4\n"
    "      масштаб.x = 0.35\n"
    "      масштаб.y = 0.35\n"
    "      масштаб.z = 0.35\n"
    "    кадр\n"
    "      вращение.x += 4.0 * дт\n";

static const char* kPresets[3] = {
    // 0: Reverse spin on tap (exact example!)
    "скорость = 3\n"
    "старт\n"
    "  позиция.y = 1\n"
    "кадр\n"
    "  вращение.y += скорость * дт\n"
    "  если касание\n"
    "    скорость = -скорость\n",

    // 1: Jump on tap + gravity
    "vy = 0\n"
    "кадр\n"
    "  вращение.y += 2.0 * дт\n"
    "  если касание и позиция.y <= 0.05\n"
    "    vy = 6.0\n"
    "  vy -= 14.0 * дт\n"
    "  позиция.y += vy * дт\n"
    "  если позиция.y < 0\n"
    "    позиция.y = 0\n"
    "    vy = 0\n",

    // 2: Orbit wave
    "кадр\n"
    "  позиция.x = косинус(время * 2.0) * 2.0\n"
    "  позиция.z = синус(время * 2.0) * 2.0\n"
    "  позиция.y = 0.6 + синус(время * 4.0) * 0.4\n"
};

static void initDefaultScene() {
    g.nextNodeId = 1;
    g.root = std::make_unique<SceneNode>();
    g.root->id = g.nextNodeId++;
    g.root->name = "Root";
    g.root->type = NodeType::Node3D;

    loadSceneFromNovaScript(kDefaultSceneScript, g.root.get(), g.nextNodeId);
    if (g.root->children.size() >= 2)
        g.selected = g.root->children[1].get();
    else
        g.selected = g.root.get();
}

static uint32_t findMem(uint32_t bits, VkMemoryPropertyFlags want) {
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(g.phys, &mp);
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & want) == want) return i;
    abort();
}

static void makeBuffer(const void* data, VkDeviceSize size, VkBufferUsageFlags usage,
                       VkBuffer& buf, VkDeviceMemory& mem, void** outMapped = nullptr) {
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size; bi.usage = usage; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VK_CHECK(vkCreateBuffer(g.dev, &bi, nullptr, &buf));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(g.dev, buf, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    VK_CHECK(vkAllocateMemory(g.dev, &ai, nullptr, &mem));
    VK_CHECK(vkBindBufferMemory(g.dev, buf, mem, 0));
    void* p = nullptr;
    VK_CHECK(vkMapMemory(g.dev, mem, 0, size, 0, &p));
    if (data) memcpy(p, data, (size_t)size);
    if (outMapped) *outMapped = p;
    else vkUnmapMemory(g.dev, mem);
}

static VkShaderModule makeShader(const uint32_t* code, size_t bytes) {
    VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    ci.codeSize = bytes; ci.pCode = code;
    VkShaderModule m;
    VK_CHECK(vkCreateShaderModule(g.dev, &ci, nullptr, &m));
    return m;
}

static void addFace(std::vector<Vertex3D>& vs, std::vector<uint16_t>& is, Vec3 n, Vec3 u,
                    Vec3 v, Vec3 center, float half, Vec3 col) {
    uint16_t base = (uint16_t)vs.size();
    const float su[4] = {-1, 1, 1, -1}, sv[4] = {-1, -1, 1, 1};
    for (int i = 0; i < 4; i++) {
        Vertex3D x;
        x.pos[0] = center.x + (n.x + u.x * su[i] + v.x * sv[i]) * half;
        x.pos[1] = center.y + (n.y + u.y * su[i] + v.y * sv[i]) * half;
        x.pos[2] = center.z + (n.z + u.z * su[i] + v.z * sv[i]) * half;
        x.nrm[0] = n.x; x.nrm[1] = n.y; x.nrm[2] = n.z;
        x.col[0] = col.x; x.col[1] = col.y; x.col[2] = col.z;
        vs.push_back(x);
    }
    const uint16_t idx[6] = {0, 1, 2, 0, 2, 3};
    for (uint16_t i : idx) is.push_back(base + i);
}

static void pushRect(float px, float py, float pw, float ph, float r, float gr, float b, float a = 0.92f) {
    float W = (float)g.extent.width, H = (float)g.extent.height;
    float x0 = (px / W) * 2.f - 1.f;
    float y0 = (py / H) * 2.f - 1.f;
    float x1 = ((px + pw) / W) * 2.f - 1.f;
    float y1 = ((py + ph) / H) * 2.f - 1.f;
    if (g.uiVerts.size() + 6 > kMaxUiVerts) return;
    Vertex2D v0{{x0, y0}, {r, gr, b, a}}, v1{{x1, y0}, {r, gr, b, a}};
    Vertex2D v2{{x1, y1}, {r, gr, b, a}}, v3{{x0, y1}, {r, gr, b, a}};
    g.uiVerts.push_back(v0); g.uiVerts.push_back(v1); g.uiVerts.push_back(v2);
    g.uiVerts.push_back(v0); g.uiVerts.push_back(v2); g.uiVerts.push_back(v3);
}

static void pushText(float px, float py, float scale, const std::string& s, float r = 1, float gr = 1, float b = 1) {
    size_t colIdx = 0;
    for (size_t i = 0; i < s.size(); i++) {
        unsigned char uc = (unsigned char)s[i];
        if (uc >= 0x80) {
            if ((uc & 0xC0) == 0x80) continue; // skip UTF-8 continuation bytes
        }
        const uint8_t* col = glyph5x7(uc < 0x80 ? (char)uc : 'N');
        for (int cx = 0; cx < 5; cx++) {
            uint8_t bits = col[cx];
            for (int cy = 0; cy < 7; cy++) {
                if (bits & (1 << cy)) {
                    pushRect(px + (colIdx * 6 + cx) * scale, py + cy * scale, scale, scale, r, gr, b, 1.f);
                }
            }
        }
        colIdx++;
    }
}

static void addButton(float x, float y, float w, float h, const std::string& label, int act, int param,
                      float r, float gr, float b) {
    g.buttons.push_back({x, y, w, h, label, act, param, r, gr, b});
    pushRect(x, y, w, h, r, gr, b, 0.92f);
    pushText(x + 12.f, y + (h - 21.f) * 0.5f, 3.0f, label, 1.f, 1.f, 1.f);
}

static void collectTreeFlat(SceneNode* n, int depth, std::vector<std::pair<SceneNode*, int>>& out) {
    out.push_back({n, depth});
    for (auto& c : n->children) collectTreeFlat(c.get(), depth + 1, out);
}

static void buildEditorUI() {
    g.uiVerts.clear();
    g.buttons.clear();
    float W = (float)g.extent.width;
    float H = (float)g.extent.height;

    pushRect(0, 0, W, 68, 0.08f, 0.09f, 0.13f, 0.95f);
    char hdr[64];
    snprintf(hdr, sizeof(hdr), "NOVA ENGINE  FPS %.0f", g.fps);
    pushText(20, 22, 3.2f, hdr, 0.45f, 0.85f, 1.0f);

    if (g.playing)
        addButton(W * 0.42f, 10, 170, 48, "STOP", 1, 0, 0.80f, 0.25f, 0.25f);
    else
        addButton(W * 0.42f, 10, 170, 48, "PLAY", 1, 1, 0.20f, 0.72f, 0.35f);

    addButton(W * 0.42f + 185, 10, 180, 48, "+ CUBE", 2, 0, 0.22f, 0.35f, 0.55f);
    addButton(W * 0.42f + 380, 10, 190, 48, "+ CHILD", 3, 0, 0.25f, 0.45f, 0.40f);
    addButton(W - 180, 10, 160, 48, "RESET", 4, 0, 0.35f, 0.30f, 0.45f);

    float leftW = 340.f;
    pushRect(0, 68, leftW, H - 68, 0.07f, 0.08f, 0.11f, 0.88f);
    pushText(16, 82, 2.8f, "NODES", 0.65f, 0.75f, 0.95f);

    std::vector<std::pair<SceneNode*, int>> flat;
    collectTreeFlat(g.root.get(), 0, flat);
    float ny = 120.f;
    for (auto& item : flat) {
        SceneNode* node = item.first;
        int depth = item.second;
        bool isSel = (node == g.selected);
        std::string prefix(depth * 2, ' ');
        if (depth > 0) prefix += "> ";
        addButton(10.f, ny, leftW - 20.f, 44.f, prefix + node->name, 10, node->id,
                  isSel ? 0.24f : 0.13f, isSel ? 0.45f : 0.15f, isSel ? 0.75f : 0.21f);
        ny += 50.f;
        if (ny > H - 60.f) break;
    }

    if (g.selected) {
        float rightW = 380.f;
        float rx = W - rightW;
        pushRect(rx, 68, rightW, H - 68, 0.07f, 0.08f, 0.11f, 0.88f);
        pushText(rx + 16, 82, 2.8f, "NODE ID " + std::to_string(g.selected->id), 0.95f, 0.80f, 0.45f);

        char buf[64];
        snprintf(buf, sizeof(buf), "POS X %.1f  Y %.1f  Z %.1f", g.selected->pos.x, g.selected->pos.y, g.selected->pos.z);
        pushText(rx + 16, 125, 2.4f, buf, 0.85f, 0.90f, 0.95f);

        addButton(rx + 16, 155, 105, 42, "X -", 20, 0, 0.25f, 0.20f, 0.25f);
        addButton(rx + 131, 155, 105, 42, "X +", 20, 1, 0.20f, 0.30f, 0.25f);
        addButton(rx + 246, 155, 118, 42, "Y +1", 20, 2, 0.20f, 0.30f, 0.35f);

        pushText(rx + 16, 220, 2.6f, "NOVASCRIPT:", 0.55f, 0.95f, 0.65f);
        addButton(rx + 16, 255, rightW - 32, 44, "1: SPIN + TAP REVERSE", 30, 0, 0.18f, 0.28f, 0.36f);
        addButton(rx + 16, 307, rightW - 32, 44, "2: TAP JUMP + GRAVITY", 30, 1, 0.18f, 0.28f, 0.36f);
        addButton(rx + 16, 359, rightW - 32, 44, "3: ORBIT WAVE", 30, 2, 0.18f, 0.28f, 0.36f);
        addButton(rx + 16, 411, rightW - 32, 44, "CLEAR SCRIPT", 30, -1, 0.32f, 0.18f, 0.20f);
    }
}

static SceneNode* findNodeById(SceneNode* n, int id) {
    if (n->id == id) return n;
    for (auto& c : n->children) {
        if (auto* f = findNodeById(c.get(), id)) return f;
    }
    return nullptr;
}

static void handleButton(const UIButton& b) {
    if (b.actionId == 1) {
        g.playing = (b.param == 1);
    } else if (b.actionId == 2) {
        std::string name = "Cube" + std::to_string(g.nextNodeId);
        SceneNode* n = g.root->addChild(name, NodeType::CubeMesh, g.nextNodeId);
        n->pos = {(float)((g.nextNodeId % 5) - 2) * 1.4f, 0.5f, (float)((g.nextNodeId % 3) - 1) * 1.2f};
        n->scriptSource = kPresets[0];
        n->compileScript();
        g.selected = n;
    } else if (b.actionId == 3 && g.selected) {
        std::string name = "Child" + std::to_string(g.nextNodeId);
        SceneNode* n = g.selected->addChild(name, NodeType::CubeMesh, g.nextNodeId);
        n->pos = {1.2f, 0.3f, 0.f};
        n->scale = {0.4f, 0.4f, 0.4f};
        n->scriptSource = "кадр\n  вращение.y += 3.0 * дт\n";
        n->compileScript();
        g.selected = n;
    } else if (b.actionId == 4) {
        initDefaultScene();
    } else if (b.actionId == 10) {
        if (auto* found = findNodeById(g.root.get(), b.param)) g.selected = found;
    } else if (b.actionId == 20 && g.selected) {
        if (b.param == 0) g.selected->pos.x -= 0.5f;
        if (b.param == 1) g.selected->pos.x += 0.5f;
        if (b.param == 2) g.selected->pos.y += 1.0f;
    } else if (b.actionId == 30 && g.selected) {
        g.selected->scriptSource = (b.param >= 0) ? kPresets[b.param] : "";
        g.selected->compileScript();
    }
}

static void createInstance() {
    const char* exts[] = {"VK_KHR_surface", "VK_KHR_android_surface"};
    VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.pApplicationName = "NovaEngine"; ai.apiVersion = VK_API_VERSION_1_0;
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &ai; ci.enabledExtensionCount = 2; ci.ppEnabledExtensionNames = exts;
    VK_CHECK(vkCreateInstance(&ci, nullptr, &g.instance));
}

static void createSurface() {
    VkAndroidSurfaceCreateInfoKHR ci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    ci.window = g.app->window;
    VK_CHECK(vkCreateAndroidSurfaceKHR(g.instance, &ci, nullptr, &g.surface));
}

static void createDeviceAndBuffers() {
    uint32_t n = 0;
    vkEnumeratePhysicalDevices(g.instance, &n, nullptr);
    std::vector<VkPhysicalDevice> pds(n);
    vkEnumeratePhysicalDevices(g.instance, &n, pds.data());
    for (auto pd : pds) {
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qs(qn);
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, qs.data());
        for (uint32_t i = 0; i < qn; i++) {
            VkBool32 present = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, g.surface, &present);
            if ((qs[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && present) { g.phys = pd; g.qfam = i; break; }
        }
        if (g.phys) break;
    }
    float prio = 1.f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = g.qfam; qci.queueCount = 1; qci.pQueuePriorities = &prio;
    const char* dexts[] = {"VK_KHR_swapchain"};
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = 1; dci.ppEnabledExtensionNames = dexts;
    VK_CHECK(vkCreateDevice(g.phys, &dci, nullptr, &g.dev));
    vkGetDeviceQueue(g.dev, g.qfam, 0, &g.queue);

    VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT; pci.queueFamilyIndex = g.qfam;
    VK_CHECK(vkCreateCommandPool(g.dev, &pci, nullptr, &g.pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = g.pool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = kFrames;
    VK_CHECK(vkAllocateCommandBuffers(g.dev, &cai, g.cmd));

    for (int i = 0; i < kFrames; i++) {
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VK_CHECK(vkCreateSemaphore(g.dev, &si, nullptr, &g.imgAvail[i]));
        VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        VK_CHECK(vkCreateFence(g.dev, &fi, nullptr, &g.fence[i]));
        makeBuffer(nullptr, kMaxUiVerts * sizeof(Vertex2D), VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
                   g.uiVbuf[i], g.uiVmem[i], &g.uiMapped[i]);
    }

    VkPushConstantRange pcr{VK_SHADER_STAGE_VERTEX_BIT, 0, 128};
    VkPipelineLayoutCreateInfo lci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    lci.pushConstantRangeCount = 1; lci.pPushConstantRanges = &pcr;
    VK_CHECK(vkCreatePipelineLayout(g.dev, &lci, nullptr, &g.pipeLayout3D));

    VkPipelineLayoutCreateInfo ulci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    VK_CHECK(vkCreatePipelineLayout(g.dev, &ulci, nullptr, &g.pipeLayoutUI));

    std::vector<Vertex3D> vs;
    std::vector<uint16_t> is;
    const float h = 0.5f;
    addFace(vs, is, {1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, 0}, h, {0.90f, 0.28f, 0.24f});
    addFace(vs, is, {-1, 0, 0}, {0, 0, 1}, {0, 1, 0}, {0, 0, 0}, h, {0.24f, 0.74f, 0.35f});
    addFace(vs, is, {0, 1, 0}, {0, 0, 1}, {1, 0, 0}, {0, 0, 0}, h, {0.28f, 0.50f, 0.96f});
    addFace(vs, is, {0, -1, 0}, {1, 0, 0}, {0, 0, 1}, {0, 0, 0}, h, {0.95f, 0.80f, 0.22f});
    addFace(vs, is, {0, 0, 1}, {1, 0, 0}, {0, 1, 0}, {0, 0, 0}, h, {0.82f, 0.34f, 0.82f});
    addFace(vs, is, {0, 0, -1}, {0, 1, 0}, {1, 0, 0}, {0, 0, 0}, h, {0.22f, 0.82f, 0.86f});
    g.cubeIndexCount = (uint32_t)is.size();
    g.floorFirstIndex = g.cubeIndexCount;
    {
        uint16_t base = (uint16_t)vs.size();
        const float s = 10.f;
        const float px[4] = {-s, s, s, -s}, pz[4] = {s, s, -s, -s};
        for (int i = 0; i < 4; i++) vs.push_back({{px[i], 0.f, pz[i]}, {0, 1, 0}, {0.34f, 0.36f, 0.40f}});
        const uint16_t idx[6] = {0, 1, 2, 0, 2, 3};
        for (uint16_t i : idx) is.push_back(base + i);
    }
    g.floorIndexCount = 6;
    makeBuffer(vs.data(), vs.size() * sizeof(Vertex3D), VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, g.vbuf, g.vmem);
    makeBuffer(is.data(), is.size() * sizeof(uint16_t), VK_BUFFER_USAGE_INDEX_BUFFER_BIT, g.ibuf, g.imem);
}

static void destroySwapchainStuff() {
    if (!g.dev) return;
    vkDeviceWaitIdle(g.dev);
    if (g.pipeline3D) vkDestroyPipeline(g.dev, g.pipeline3D, nullptr);
    if (g.pipelineUI) vkDestroyPipeline(g.dev, g.pipelineUI, nullptr);
    if (g.rp) vkDestroyRenderPass(g.dev, g.rp, nullptr);
    for (auto f : g.fbs) vkDestroyFramebuffer(g.dev, f, nullptr);
    for (auto v : g.views) vkDestroyImageView(g.dev, v, nullptr);
    for (auto s : g.renderDone) vkDestroySemaphore(g.dev, s, nullptr);
    if (g.depthView) vkDestroyImageView(g.dev, g.depthView, nullptr);
    if (g.depthImg) vkDestroyImage(g.dev, g.depthImg, nullptr);
    if (g.depthMem) vkFreeMemory(g.dev, g.depthMem, nullptr);
    if (g.swapchain) vkDestroySwapchainKHR(g.dev, g.swapchain, nullptr);
    g.pipeline3D = VK_NULL_HANDLE; g.pipelineUI = VK_NULL_HANDLE; g.rp = VK_NULL_HANDLE;
    g.fbs.clear(); g.views.clear(); g.renderDone.clear(); g.images.clear();
    g.depthView = VK_NULL_HANDLE; g.depthImg = VK_NULL_HANDLE; g.depthMem = VK_NULL_HANDLE;
    g.swapchain = VK_NULL_HANDLE;
}

static void createSwapchainStuff() {
    VkSurfaceCapabilitiesKHR caps;
    VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g.phys, g.surface, &caps));
    uint32_t fn = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surface, &fn, nullptr);
    std::vector<VkSurfaceFormatKHR> fmts(fn);
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surface, &fn, fmts.data());
    VkSurfaceFormatKHR chosen = fmts[0];
    for (auto& f : fmts)
        if (f.format == VK_FORMAT_R8G8B8A8_SRGB || f.format == VK_FORMAT_B8G8R8A8_SRGB) { chosen = f; break; }
    g.colorFormat = chosen.format;
    g.extent = caps.currentExtent;
    if (g.extent.width == 0xFFFFFFFFu) {
        g.extent.width = (uint32_t)ANativeWindow_getWidth(g.app->window);
        g.extent.height = (uint32_t)ANativeWindow_getHeight(g.app->window);
    }
    uint32_t imageCount = caps.minImageCount + 1;
    if (caps.maxImageCount > 0) imageCount = std::min(imageCount, caps.maxImageCount);
    VkCompositeAlphaFlagBitsKHR alpha = (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR)
        ? VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR : VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;

    VkSwapchainCreateInfoKHR sci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    sci.surface = g.surface; sci.minImageCount = imageCount;
    sci.imageFormat = chosen.format; sci.imageColorSpace = chosen.colorSpace;
    sci.imageExtent = g.extent; sci.imageArrayLayers = 1;
    sci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    sci.preTransform = (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR)
        ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR : caps.currentTransform;
    sci.compositeAlpha = alpha; sci.presentMode = VK_PRESENT_MODE_FIFO_KHR; sci.clipped = VK_TRUE;
    VK_CHECK(vkCreateSwapchainKHR(g.dev, &sci, nullptr, &g.swapchain));

    uint32_t in = 0;
    vkGetSwapchainImagesKHR(g.dev, g.swapchain, &in, nullptr);
    g.images.resize(in);
    vkGetSwapchainImagesKHR(g.dev, g.swapchain, &in, g.images.data());

    VkImageCreateInfo di{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    di.imageType = VK_IMAGE_TYPE_2D; di.format = VK_FORMAT_D32_SFLOAT;
    di.extent = {g.extent.width, g.extent.height, 1}; di.mipLevels = 1; di.arrayLayers = 1;
    di.samples = VK_SAMPLE_COUNT_1_BIT; di.tiling = VK_IMAGE_TILING_OPTIMAL;
    di.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    VK_CHECK(vkCreateImage(g.dev, &di, nullptr, &g.depthImg));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(g.dev, g.depthImg, &mr);
    VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    mai.allocationSize = mr.size;
    mai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VK_CHECK(vkAllocateMemory(g.dev, &mai, nullptr, &g.depthMem));
    VK_CHECK(vkBindImageMemory(g.dev, g.depthImg, g.depthMem, 0));
    VkImageViewCreateInfo dvi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    dvi.image = g.depthImg; dvi.viewType = VK_IMAGE_VIEW_TYPE_2D; dvi.format = VK_FORMAT_D32_SFLOAT;
    dvi.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
    VK_CHECK(vkCreateImageView(g.dev, &dvi, nullptr, &g.depthView));

    VkAttachmentDescription at[2]{};
    at[0].format = g.colorFormat; at[0].samples = VK_SAMPLE_COUNT_1_BIT;
    at[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; at[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    at[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    at[1].format = VK_FORMAT_D32_SFLOAT; at[1].samples = VK_SAMPLE_COUNT_1_BIT;
    at[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; at[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    VkAttachmentReference cref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkAttachmentReference dref{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sp{};
    sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sp.colorAttachmentCount = 1; sp.pColorAttachments = &cref; sp.pDepthStencilAttachment = &dref;
    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL; dep.dstSubpass = 0;
    dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dep.dstStageMask = dep.srcStageMask;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    VkRenderPassCreateInfo rci{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    rci.attachmentCount = 2; rci.pAttachments = at; rci.subpassCount = 1; rci.pSubpasses = &sp;
    rci.dependencyCount = 1; rci.pDependencies = &dep;
    VK_CHECK(vkCreateRenderPass(g.dev, &rci, nullptr, &g.rp));

    for (auto img : g.images) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = g.colorFormat;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VkImageView v; VK_CHECK(vkCreateImageView(g.dev, &vi, nullptr, &v));
        g.views.push_back(v);
        VkImageView att[2] = {v, g.depthView};
        VkFramebufferCreateInfo fci{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fci.renderPass = g.rp; fci.attachmentCount = 2; fci.pAttachments = att;
        fci.width = g.extent.width; fci.height = g.extent.height; fci.layers = 1;
        VkFramebuffer fb; VK_CHECK(vkCreateFramebuffer(g.dev, &fci, nullptr, &fb));
        g.fbs.push_back(fb);
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VkSemaphore s; VK_CHECK(vkCreateSemaphore(g.dev, &si, nullptr, &s));
        g.renderDone.push_back(s);
    }

    VkShaderModule vsm = makeShader(kVertSpv, sizeof(kVertSpv));
    VkShaderModule fsm = makeShader(kFragSpv, sizeof(kFragSpv));
    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vsm; st[0].pName = "main";
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fsm; st[1].pName = "main";

    VkVertexInputBindingDescription bind{0, sizeof(Vertex3D), VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription attr[3] = {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex3D, pos)},
        {1, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex3D, nrm)},
        {2, 0, VK_FORMAT_R32G32B32_SFLOAT, offsetof(Vertex3D, col)}};
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    vin.vertexBindingDescriptionCount = 1; vin.pVertexBindingDescriptions = &bind;
    vin.vertexAttributeDescriptionCount = 3; vin.pVertexAttributeDescriptions = attr;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1; vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_BACK_BIT;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE; rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    ds.depthTestEnable = VK_TRUE; ds.depthWriteEnable = VK_TRUE; ds.depthCompareOp = VK_COMPARE_OP_LESS;
    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = 0xF;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dsi{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dsi.dynamicStateCount = 2; dsi.pDynamicStates = dyn;

    VkGraphicsPipelineCreateInfo gp{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gp.stageCount = 2; gp.pStages = st; gp.pVertexInputState = &vin; gp.pInputAssemblyState = &ia;
    gp.pViewportState = &vp; gp.pRasterizationState = &rs; gp.pMultisampleState = &ms;
    gp.pDepthStencilState = &ds; gp.pColorBlendState = &cb; gp.pDynamicState = &dsi;
    gp.layout = g.pipeLayout3D; gp.renderPass = g.rp;
    VK_CHECK(vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &gp, nullptr, &g.pipeline3D));
    vkDestroyShaderModule(g.dev, vsm, nullptr);
    vkDestroyShaderModule(g.dev, fsm, nullptr);

    VkShaderModule uvsm = makeShader(kUiVertSpv, sizeof(kUiVertSpv));
    VkShaderModule ufsm = makeShader(kUiFragSpv, sizeof(kUiFragSpv));
    st[0].module = uvsm; st[1].module = ufsm;
    VkVertexInputBindingDescription ubind{0, sizeof(Vertex2D), VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription uattr[2] = {
        {0, 0, VK_FORMAT_R32G32_SFLOAT, offsetof(Vertex2D, pos)},
        {1, 0, VK_FORMAT_R32G32B32A32_SFLOAT, offsetof(Vertex2D, col)}};
    vin.pVertexBindingDescriptions = &ubind;
    vin.vertexAttributeDescriptionCount = 2; vin.pVertexAttributeDescriptions = uattr;
    rs.cullMode = VK_CULL_MODE_NONE;
    ds.depthTestEnable = VK_FALSE; ds.depthWriteEnable = VK_FALSE;
    cba.blendEnable = VK_TRUE;
    cba.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
    cba.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
    cba.colorBlendOp = VK_BLEND_OP_ADD;
    cba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
    cba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
    cba.alphaBlendOp = VK_BLEND_OP_ADD;
    gp.layout = g.pipeLayoutUI;
    VK_CHECK(vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &gp, nullptr, &g.pipelineUI));
    vkDestroyShaderModule(g.dev, uvsm, nullptr);
    vkDestroyShaderModule(g.dev, ufsm, nullptr);
}

static void recreateSwapchain() { destroySwapchainStuff(); createSwapchainStuff(); g.needRecreate = false; }

struct PushData { Mat4 mvp; Mat4 model; };

static void renderNodeRecursive(VkCommandBuffer cb, const Mat4& vpm, SceneNode* node) {
    Mat4 world = node->globalTransform();
    if (node->type == NodeType::CubeMesh || node->type == NodeType::FloorMesh) {
        PushData pd;
        pd.model = world;
        pd.mvp = matMul(vpm, world);
        vkCmdPushConstants(cb, g.pipeLayout3D, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(pd), &pd);
        if (node->type == NodeType::FloorMesh)
            vkCmdDrawIndexed(cb, g.floorIndexCount, 1, g.floorFirstIndex, 0, 0);
        else
            vkCmdDrawIndexed(cb, g.cubeIndexCount, 1, 0, 0, 0);
    }
    for (auto& c : node->children) renderNodeRecursive(cb, vpm, c.get());
}

static void drawFrame() {
    auto now = std::chrono::steady_clock::now();
    float dt = std::min(0.05f, std::chrono::duration<float>(now - g.last).count());
    g.last = now;
    g.totalTime += dt;
    g.fpsTimer += dt; g.fpsFrames++;
    if (g.fpsTimer >= 0.5f) { g.fps = g.fpsFrames / g.fpsTimer; g.fpsTimer = 0; g.fpsFrames = 0; }

    InputState in{g.lastX, g.lastY, g.touchDx, g.touchDy, g.dragging, g.tapOccurred, g.totalTime};
    g.root->step(g.playing, dt, in);
    g.touchDx = 0; g.touchDy = 0; g.tapOccurred = false;

    buildEditorUI();
    int f = g.frame;
    vkWaitForFences(g.dev, 1, &g.fence[f], VK_TRUE, UINT64_MAX);
    uint32_t idx;
    VkResult r = vkAcquireNextImageKHR(g.dev, g.swapchain, UINT64_MAX, g.imgAvail[f], VK_NULL_HANDLE, &idx);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) { recreateSwapchain(); return; }
    vkResetFences(g.dev, 1, &g.fence[f]);
    vkResetCommandBuffer(g.cmd[f], 0);

    if (!g.uiVerts.empty())
        memcpy(g.uiMapped[f], g.uiVerts.data(), g.uiVerts.size() * sizeof(Vertex2D));

    VkCommandBuffer cb = g.cmd[f];
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    VK_CHECK(vkBeginCommandBuffer(cb, &bi));

    VkClearValue clears[2];
    clears[0].color = {{0.05f, 0.07f, 0.11f, 1.f}};
    clears[1].depthStencil = {1.f, 0};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rb.renderPass = g.rp; rb.framebuffer = g.fbs[idx]; rb.renderArea = {{0, 0}, g.extent};
    rb.clearValueCount = 2; rb.pClearValues = clears;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);

    VkViewport vp{0, 0, (float)g.extent.width, (float)g.extent.height, 0.f, 1.f};
    VkRect2D sc{{0, 0}, g.extent};
    vkCmdSetViewport(cb, 0, 1, &vp);
    vkCmdSetScissor(cb, 0, 1, &sc);

    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pipeline3D);
    VkDeviceSize off = 0;
    vkCmdBindVertexBuffers(cb, 0, 1, &g.vbuf, &off);
    vkCmdBindIndexBuffer(cb, g.ibuf, 0, VK_INDEX_TYPE_UINT16);

    float aspect = (float)g.extent.width / (float)g.extent.height;
    Mat4 proj = perspective(1.0f, aspect, 0.1f, 80.f);
    Vec3 eye{std::sin(g.camYaw) * std::cos(g.camPitch) * g.camDist,
             std::sin(g.camPitch) * g.camDist + 1.0f,
             std::cos(g.camYaw) * std::cos(g.camPitch) * g.camDist};
    Mat4 vpm = matMul(proj, lookAt(eye, {0.f, 0.4f, 0.f}, {0.f, 1.f, 0.f}));
    renderNodeRecursive(cb, vpm, g.root.get());

    if (!g.uiVerts.empty()) {
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pipelineUI);
        vkCmdBindVertexBuffers(cb, 0, 1, &g.uiVbuf[f], &off);
        vkCmdDraw(cb, (uint32_t)g.uiVerts.size(), 1, 0, 0);
    }

    vkCmdEndRenderPass(cb);
    VK_CHECK(vkEndCommandBuffer(cb));

    VkPipelineStageFlags wait = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.waitSemaphoreCount = 1; si.pWaitSemaphores = &g.imgAvail[f]; si.pWaitDstStageMask = &wait;
    si.commandBufferCount = 1; si.pCommandBuffers = &g.cmd[f];
    si.signalSemaphoreCount = 1; si.pSignalSemaphores = &g.renderDone[idx];
    VK_CHECK(vkQueueSubmit(g.queue, 1, &si, g.fence[f]));

    VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
    pi.waitSemaphoreCount = 1; pi.pWaitSemaphores = &g.renderDone[idx];
    pi.swapchainCount = 1; pi.pSwapchains = &g.swapchain; pi.pImageIndices = &idx;
    r = vkQueuePresentKHR(g.queue, &pi);
    if (r == VK_ERROR_OUT_OF_DATE_KHR || g.needRecreate) recreateSwapchain();
    g.frame = (g.frame + 1) % kFrames;
}

static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) {
                if (!g.instance) createInstance();
                createSurface();
                if (!g.dev) createDeviceAndBuffers();
                createSwapchainStuff();
                g.last = std::chrono::steady_clock::now();
                g.ready = true;
            }
            break;
        case APP_CMD_TERM_WINDOW:
            g.ready = false;
            destroySwapchainStuff();
            if (g.surface) { vkDestroySurfaceKHR(g.instance, g.surface, nullptr); g.surface = VK_NULL_HANDLE; }
            break;
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            g.needRecreate = true;
            break;
        default: break;
    }
}

static int32_t onInput(android_app*, AInputEvent* ev) {
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;
    int32_t action = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
    float x = AMotionEvent_getX(ev, 0), y = AMotionEvent_getY(ev, 0);
    if (action == AMOTION_EVENT_ACTION_DOWN) {
        for (const auto& b : g.buttons) {
            if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) {
                handleButton(b);
                g.lastX = x; g.lastY = y;
                return 1;
            }
        }
        g.dragging = true;
        g.tapOccurred = true;
    } else if (action == AMOTION_EVENT_ACTION_MOVE && g.dragging) {
        g.touchDx = x - g.lastX;
        g.touchDy = y - g.lastY;
        g.camYaw -= g.touchDx * 0.008f;
        g.camPitch = std::max(-0.2f, std::min(1.4f, g.camPitch + g.touchDy * 0.008f));
    } else if (action == AMOTION_EVENT_ACTION_UP || action == AMOTION_EVENT_ACTION_CANCEL) {
        g.dragging = false;
    }
    g.lastX = x; g.lastY = y;
    return 1;
}

void android_main(android_app* app) {
    g.app = app;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;
    initDefaultScene();
    while (!app->destroyRequested) {
        int events;
        android_poll_source* src;
        while (ALooper_pollOnce(g.ready ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) break;
        }
        if (g.ready && !app->destroyRequested) drawFrame();
    }
    destroySwapchainStuff();
}