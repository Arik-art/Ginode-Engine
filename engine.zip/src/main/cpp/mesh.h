// Procedural meshes (cube, plane, sphere). Pure C++, no platform deps.
#pragma once
#include <cmath>
#include <cstdint>
#include <vector>
#include "gino.h"

struct Vertex { float pos[3]; float nrm[3]; float col[3]; };
using gino::Vec3;

struct MeshRange { uint32_t first = 0, count = 0; };
struct MeshSet {
    std::vector<Vertex> vs;
    std::vector<uint16_t> is;
    MeshRange cube, plane, sphere;
};

static inline void addFace(std::vector<Vertex>& vs, std::vector<uint16_t>& is, Vec3 n, Vec3 u,
                           Vec3 v, Vec3 center, float half) {
    uint16_t base = (uint16_t)vs.size();
    const float su[4] = {-1, 1, 1, -1};
    const float sv[4] = {-1, -1, 1, 1};
    for (int i = 0; i < 4; i++) {
        Vertex x;
        x.pos[0] = center.x + (n.x + u.x * su[i] + v.x * sv[i]) * half;
        x.pos[1] = center.y + (n.y + u.y * su[i] + v.y * sv[i]) * half;
        x.pos[2] = center.z + (n.z + u.z * su[i] + v.z * sv[i]) * half;
        x.nrm[0] = n.x; x.nrm[1] = n.y; x.nrm[2] = n.z;
        x.col[0] = x.col[1] = x.col[2] = 1.f;
        vs.push_back(x);
    }
    const uint16_t idx[6] = {0, 1, 2, 0, 2, 3};
    for (uint16_t i : idx) is.push_back(base + i);
}

static inline MeshSet buildMeshes() {
    MeshSet m;
    const float h = 0.5f;
    // cube
    m.cube.first = (uint32_t)m.is.size();
    addFace(m.vs, m.is, {1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, 0}, h);
    addFace(m.vs, m.is, {-1, 0, 0}, {0, 0, 1}, {0, 1, 0}, {0, 0, 0}, h);
    addFace(m.vs, m.is, {0, 1, 0}, {0, 0, 1}, {1, 0, 0}, {0, 0, 0}, h);
    addFace(m.vs, m.is, {0, -1, 0}, {1, 0, 0}, {0, 0, 1}, {0, 0, 0}, h);
    addFace(m.vs, m.is, {0, 0, 1}, {1, 0, 0}, {0, 1, 0}, {0, 0, 0}, h);
    addFace(m.vs, m.is, {0, 0, -1}, {0, 1, 0}, {1, 0, 0}, {0, 0, 0}, h);
    m.cube.count = (uint32_t)m.is.size() - m.cube.first;
    // plane: 1x1 on XZ at y = 0, facing +Y
    m.plane.first = (uint32_t)m.is.size();
    addFace(m.vs, m.is, {0, 1, 0}, {0, 0, 1}, {1, 0, 0}, {0, -0.5f, 0}, h);
    m.plane.count = (uint32_t)m.is.size() - m.plane.first;
    // sphere: radius 0.5
    m.sphere.first = (uint32_t)m.is.size();
    const int segs = 24, rings = 16;
    const float PI = 3.14159265f;
    uint16_t base = (uint16_t)m.vs.size();
    for (int i = 0; i <= rings; i++) {
        float th = PI * i / rings;
        for (int j = 0; j <= segs; j++) {
            float ph = 2 * PI * j / segs;
            float nx = std::sin(th) * std::cos(ph), ny = std::cos(th), nz = std::sin(th) * std::sin(ph);
            Vertex x;
            x.pos[0] = nx * 0.5f; x.pos[1] = ny * 0.5f; x.pos[2] = nz * 0.5f;
            x.nrm[0] = nx; x.nrm[1] = ny; x.nrm[2] = nz;
            x.col[0] = x.col[1] = x.col[2] = 1.f;
            m.vs.push_back(x);
        }
    }
    for (int i = 0; i < rings; i++)
        for (int j = 0; j < segs; j++) {
            uint16_t a = base + i * (segs + 1) + j, b = a + 1, c = a + (segs + 1), d = c + 1;
            uint16_t t[6] = {a, b, d, a, d, c};
            for (uint16_t k : t) m.is.push_back(k);
        }
    m.sphere.count = (uint32_t)m.is.size() - m.sphere.first;
    return m;
}
