#pragma once
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>
#include <android/log.h>

#define NS_LOG(...) __android_log_print(ANDROID_LOG_INFO, "NovaScript", __VA_ARGS__)

namespace ns {

enum Op : uint8_t {
    OP_CONST,
    OP_LOAD_VAR,
    OP_STORE_VAR,
    OP_LOAD_PROP,
    OP_STORE_PROP,
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD, OP_NEG,
    OP_EQ, OP_NEQ, OP_LT, OP_GT, OP_LE, OP_GE,
    OP_AND, OP_OR, OP_NOT,
    OP_JMP,
    OP_JMP_FALSE,
    OP_CALL_BUILTIN,
    OP_POP,
    OP_HALT
};

struct Bytecode {
    std::vector<uint8_t> code;
    std::vector<float> consts;
    std::vector<std::string> varNames;
    int fnStartIp = -1;   // старт / ready
    int fnFrameIp = -1;   // кадр / update
    int dtVarIdx = -1;    // дт / dt
    std::string error;
    bool ok = true;
};

enum PropId : uint8_t {
    PROP_POS_X = 0, PROP_POS_Y, PROP_POS_Z,
    PROP_ROT_X, PROP_ROT_Y, PROP_ROT_Z,
    PROP_SCALE_X, PROP_SCALE_Y, PROP_SCALE_Z,
    PROP_COL_R, PROP_COL_G, PROP_COL_B,
    PROP_TOUCH_X, PROP_TOUCH_Y, PROP_TOUCH_DX, PROP_TOUCH_DY, PROP_TOUCH_DOWN,
    PROP_TOUCH_TAP,
    PROP_TIME,
    PROP_COUNT
};

struct RuntimeContext {
    float props[PROP_COUNT] = {};
    std::vector<float> vars;
};

enum TokType {
    TOK_EOF, TOK_NL, TOK_NUM, TOK_IDENT, TOK_STR,
    TOK_NODE, TOK_START, TOK_FRAME,
    TOK_IF, TOK_ELIF, TOK_ELSE, TOK_WHILE, TOK_AND, TOK_OR, TOK_NOT,
    TOK_LPAREN, TOK_RPAREN, TOK_COLON, TOK_COMMA,
    TOK_ASSIGN, TOK_PLUS_EQ, TOK_MINUS_EQ, TOK_MUL_EQ, TOK_DIV_EQ,
    TOK_PLUS, TOK_MINUS, TOK_STAR, TOK_SLASH, TOK_PERCENT,
    TOK_EQ, TOK_NEQ, TOK_LT, TOK_GT, TOK_LE, TOK_GE,
    TOK_INDENT, TOK_DEDENT
};

struct Token {
    TokType type;
    std::string text;
    float num = 0.f;
    int line = 1;
};

inline bool isIdentByte(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') || c == '_' || c == '.' || c >= 0x80;
}

inline bool isIdentStart(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           c == '_' || c >= 0x80;
}

inline std::vector<Token> tokenize(const std::string& src, std::string& err) {
    std::vector<Token> out;
    std::vector<int> indents = {0};
    size_t i = 0, n = src.size();
    int line = 1;
    bool atLineStart = true;

    while (i < n) {
        if (atLineStart) {
            int spaces = 0;
            while (i < n && (src[i] == ' ' || src[i] == '\t')) {
                spaces += (src[i] == '\t') ? 4 : 1;
                i++;
            }
            if (i < n && (src[i] == '\r' || src[i] == '\n')) {
                if (src[i] == '\r' && i + 1 < n && src[i + 1] == '\n') i++;
                i++; line++;
                continue;
            }
            if (i < n && (src[i] == '#' || (src[i] == '/' && i + 1 < n && src[i + 1] == '/'))) {
                while (i < n && src[i] != '\n') i++;
                continue;
            }
            if (i >= n) break;
            if (spaces > indents.back()) {
                indents.push_back(spaces);
                out.push_back({TOK_INDENT, "", 0.f, line});
            } else {
                while (spaces < indents.back()) {
                    indents.pop_back();
                    out.push_back({TOK_DEDENT, "", 0.f, line});
                }
                if (spaces != indents.back()) {
                    err = "Line " + std::to_string(line) + ": bad indent";
                    return {};
                }
            }
            atLineStart = false;
        }

        unsigned char c = (unsigned char)src[i];
        if (c == ' ' || c == '\t') { i++; continue; }
        if (c == '#' || (c == '/' && i + 1 < n && src[i + 1] == '/')) {
            while (i < n && src[i] != '\n') i++;
            continue;
        }
        if (c == '\r' || c == '\n') {
            if (c == '\r' && i + 1 < n && src[i + 1] == '\n') i++;
            i++;
            if (!out.empty() && out.back().type != TOK_NL && out.back().type != TOK_INDENT && out.back().type != TOK_DEDENT)
                out.push_back({TOK_NL, "", 0.f, line});
            line++;
            atLineStart = true;
            continue;
        }
        if (c == '"') {
            i++;
            std::string s;
            while (i < n && src[i] != '"') { s += src[i++]; }
            if (i < n) i++;
            out.push_back({TOK_STR, s, 0.f, line});
            continue;
        }
        if ((c >= '0' && c <= '9') || (c == '.' && i + 1 < n && src[i + 1] >= '0' && src[i + 1] <= '9')) {
            size_t start = i;
            while (i < n && ((src[i] >= '0' && src[i] <= '9') || src[i] == '.')) i++;
            float v = std::strtof(src.substr(start, i - start).c_str(), nullptr);
            out.push_back({TOK_NUM, "", v, line});
            continue;
        }
        if (isIdentStart(c)) {
            size_t start = i;
            while (i < n && isIdentByte((unsigned char)src[i])) i++;
            std::string id = src.substr(start, i - start);
            TokType t = TOK_IDENT;

            if (id == "нода" || id == "узел" || id == "node") t = TOK_NODE;
            else if (id == "старт" || id == "ready" || id == "_ready") t = TOK_START;
            else if (id == "кадр" || id == "update" || id == "_process") t = TOK_FRAME;
            else if (id == "если" || id == "if") t = TOK_IF;
            else if (id == "иначе_если" || id == "elif") t = TOK_ELIF;
            else if (id == "иначе" || id == "else") t = TOK_ELSE;
            else if (id == "пока" || id == "while") t = TOK_WHILE;
            else if (id == "и" || id == "and") t = TOK_AND;
            else if (id == "или" || id == "or") t = TOK_OR;
            else if (id == "не" || id == "not") t = TOK_NOT;
            else if (id == "истина" || id == "да" || id == "true") {
                out.push_back({TOK_NUM, "", 1.f, line}); continue;
            }
            else if (id == "ложь" || id == "нет" || id == "false") {
                out.push_back({TOK_NUM, "", 0.f, line}); continue;
            }
            out.push_back({t, id, 0.f, line});
            continue;
        }

        auto two = [&](char a, char b, TokType tt) -> bool {
            if ((char)c == a && i + 1 < n && src[i + 1] == b) {
                out.push_back({tt, "", 0.f, line}); i += 2; return true;
            }
            return false;
        };
        if (two('=', '=', TOK_EQ) || two('!', '=', TOK_NEQ) || two('<', '=', TOK_LE) ||
            two('>', '=', TOK_GE) || two('+', '=', TOK_PLUS_EQ) || two('-', '=', TOK_MINUS_EQ) ||
            two('*', '=', TOK_MUL_EQ) || two('/', '=', TOK_DIV_EQ)) continue;

        i++;
        switch ((char)c) {
            case '(': out.push_back({TOK_LPAREN, "", 0.f, line}); break;
            case ')': out.push_back({TOK_RPAREN, "", 0.f, line}); break;
            case ':': out.push_back({TOK_COLON, "", 0.f, line}); break;
            case ',': out.push_back({TOK_COMMA, "", 0.f, line}); break;
            case '=': out.push_back({TOK_ASSIGN, "", 0.f, line}); break;
            case '+': out.push_back({TOK_PLUS, "", 0.f, line}); break;
            case '-': out.push_back({TOK_MINUS, "", 0.f, line}); break;
            case '*': out.push_back({TOK_STAR, "", 0.f, line}); break;
            case '/': out.push_back({TOK_SLASH, "", 0.f, line}); break;
            case '%': out.push_back({TOK_PERCENT, "", 0.f, line}); break;
            case '<': out.push_back({TOK_LT, "", 0.f, line}); break;
            case '>': out.push_back({TOK_GT, "", 0.f, line}); break;
            default: break;
        }
    }
    if (!out.empty() && out.back().type != TOK_NL) out.push_back({TOK_NL, "", 0.f, line});
    while (indents.size() > 1) {
        indents.pop_back();
        out.push_back({TOK_DEDENT, "", 0.f, line});
    }
    out.push_back({TOK_EOF, "", 0.f, line});
    return out;
}

class Compiler {
    std::vector<Token> toks;
    size_t pos = 0;
    Bytecode bc;
    std::unordered_map<std::string, int> varMap;
    std::vector<std::string> strPool;

    const Token& cur() const { return toks[pos < toks.size() ? pos : toks.size() - 1]; }
    bool match(TokType t) { if (cur().type == t) { pos++; return true; } return false; }
    void emit(uint8_t b) { bc.code.push_back(b); }
    void emitU16(uint16_t v) { bc.code.push_back(v & 0xFF); bc.code.push_back((v >> 8) & 0xFF); }
    size_t emitJump(uint8_t op) {
        emit(op);
        size_t at = bc.code.size();
        emitU16(0);
        return at;
    }
    void patchJump(size_t at, uint16_t target) {
        bc.code[at] = target & 0xFF;
        bc.code[at + 1] = (target >> 8) & 0xFF;
    }
    int getVar(const std::string& name) {
        std::string canonical = (name == "дт") ? "dt" : name;
        auto it = varMap.find(canonical);
        if (it != varMap.end()) return it->second;
        int idx = (int)bc.varNames.size();
        bc.varNames.push_back(canonical);
        varMap[canonical] = idx;
        return idx;
    }
    int propIndex(const std::string& s) {
        if (s == "позиция.x" || s == "pos.x") return PROP_POS_X;
        if (s == "позиция.y" || s == "pos.y") return PROP_POS_Y;
        if (s == "позиция.z" || s == "pos.z") return PROP_POS_Z;
        if (s == "вращение.x" || s == "rot.x") return PROP_ROT_X;
        if (s == "вращение.y" || s == "rot.y") return PROP_ROT_Y;
        if (s == "вращение.z" || s == "rot.z") return PROP_ROT_Z;
        if (s == "масштаб.x" || s == "scale.x") return PROP_SCALE_X;
        if (s == "масштаб.y" || s == "scale.y") return PROP_SCALE_Y;
        if (s == "масштаб.z" || s == "scale.z") return PROP_SCALE_Z;
        if (s == "цвет.r" || s == "color.r") return PROP_COL_R;
        if (s == "цвет.g" || s == "color.g") return PROP_COL_G;
        if (s == "цвет.b" || s == "color.b") return PROP_COL_B;
        if (s == "касание_x" || s == "touch_x") return PROP_TOUCH_X;
        if (s == "касание_y" || s == "touch_y") return PROP_TOUCH_Y;
        if (s == "сдвиг_x" || s == "touch_dx") return PROP_TOUCH_DX;
        if (s == "сдвиг_y" || s == "touch_dy") return PROP_TOUCH_DY;
        if (s == "удержание" || s == "touch_down") return PROP_TOUCH_DOWN;
        if (s == "касание" || s == "тап" || s == "tap") return PROP_TOUCH_TAP;
        if (s == "время" || s == "time") return PROP_TIME;
        return -1;
    }

    void expr() { logicOr(); }
    void logicOr() {
        logicAnd();
        while (match(TOK_OR)) { logicAnd(); emit(OP_OR); }
    }
    void logicAnd() {
        equality();
        while (match(TOK_AND)) { equality(); emit(OP_AND); }
    }
    void equality() {
        compare();
        while (true) {
            if (match(TOK_EQ)) { compare(); emit(OP_EQ); }
            else if (match(TOK_NEQ)) { compare(); emit(OP_NEQ); }
            else break;
        }
    }
    void compare() {
        term();
        while (true) {
            if (match(TOK_LT)) { term(); emit(OP_LT); }
            else if (match(TOK_GT)) { term(); emit(OP_GT); }
            else if (match(TOK_LE)) { term(); emit(OP_LE); }
            else if (match(TOK_GE)) { term(); emit(OP_GE); }
            else break;
        }
    }
    void term() {
        factor();
        while (true) {
            if (match(TOK_PLUS)) { factor(); emit(OP_ADD); }
            else if (match(TOK_MINUS)) { factor(); emit(OP_SUB); }
            else break;
        }
    }
    void factor() {
        unary();
        while (true) {
            if (match(TOK_STAR)) { unary(); emit(OP_MUL); }
            else if (match(TOK_SLASH)) { unary(); emit(OP_DIV); }
            else if (match(TOK_PERCENT)) { unary(); emit(OP_MOD); }
            else break;
        }
    }
    void unary() {
        if (match(TOK_MINUS)) { unary(); emit(OP_NEG); return; }
        if (match(TOK_NOT)) { unary(); emit(OP_NOT); return; }
        primary();
    }
    void primary() {
        if (cur().type == TOK_NUM) {
            float v = cur().num; pos++;
            uint16_t idx = (uint16_t)bc.consts.size();
            bc.consts.push_back(v);
            emit(OP_CONST); emitU16(idx);
            return;
        }
        if (cur().type == TOK_STR) {
            std::string s = cur().text; pos++;
            int id = (int)strPool.size();
            strPool.push_back(s);
            uint16_t idx = (uint16_t)bc.consts.size();
            bc.consts.push_back((float)id);
            emit(OP_CONST); emitU16(idx);
            return;
        }
        if (match(TOK_LPAREN)) {
            expr();
            match(TOK_RPAREN);
            return;
        }
        if (cur().type == TOK_IDENT) {
            std::string name = cur().text; pos++;
            if (match(TOK_LPAREN)) {
                uint8_t argc = 0;
                if (cur().type != TOK_RPAREN) {
                    do { expr(); argc++; } while (match(TOK_COMMA));
                }
                match(TOK_RPAREN);
                uint8_t bid = 0;
                if (name == "sin" || name == "синус") bid = 1;
                else if (name == "cos" || name == "косинус") bid = 2;
                else if (name == "abs" || name == "модуль") bid = 3;
                else if (name == "min" || name == "мин") bid = 4;
                else if (name == "max" || name == "макс") bid = 5;
                else if (name == "clamp" || name == "зажать") bid = 6;
                else if (name == "lerp" || name == "плавно") bid = 7;
                else if (name == "sqrt" || name == "корень") bid = 8;
                else if (name == "print" || name == "печать") bid = 9;
                emit(OP_CALL_BUILTIN);
                emit(bid);
                emit(argc);
                return;
            }
            int p = propIndex(name);
            if (p >= 0) {
                emit(OP_LOAD_PROP); emit((uint8_t)p);
            } else {
                emit(OP_LOAD_VAR); emitU16((uint16_t)getVar(name));
            }
            return;
        }
        bc.ok = false;
        bc.error = "Line " + std::to_string(cur().line) + ": unexpected token";
        pos++;
    }

    void block() {
        while (match(TOK_NL)) {}
        if (!match(TOK_INDENT)) return;
        while (cur().type != TOK_DEDENT && cur().type != TOK_EOF && bc.ok) {
            if (match(TOK_NL)) continue;
            statement();
        }
        match(TOK_DEDENT);
    }

    void statement() {
        if (match(TOK_IF)) {
            expr();
            match(TOK_COLON); // optional ':'
            size_t jFalse = emitJump(OP_JMP_FALSE);
            block();
            std::vector<size_t> endJumps;
            while (match(TOK_ELIF)) {
                endJumps.push_back(emitJump(OP_JMP));
                patchJump(jFalse, (uint16_t)bc.code.size());
                expr();
                match(TOK_COLON);
                jFalse = emitJump(OP_JMP_FALSE);
                block();
            }
            if (match(TOK_ELSE)) {
                endJumps.push_back(emitJump(OP_JMP));
                patchJump(jFalse, (uint16_t)bc.code.size());
                match(TOK_COLON);
                block();
            } else {
                patchJump(jFalse, (uint16_t)bc.code.size());
            }
            for (size_t ej : endJumps) patchJump(ej, (uint16_t)bc.code.size());
            return;
        }
        if (match(TOK_WHILE)) {
            uint16_t loopStart = (uint16_t)bc.code.size();
            expr();
            match(TOK_COLON);
            size_t jFalse = emitJump(OP_JMP_FALSE);
            block();
            size_t jBack = emitJump(OP_JMP);
            patchJump(jBack, loopStart);
            patchJump(jFalse, (uint16_t)bc.code.size());
            return;
        }
        if (cur().type == TOK_IDENT) {
            std::string name = cur().text;
            TokType next = (pos + 1 < toks.size()) ? toks[pos + 1].type : TOK_EOF;
            if (next == TOK_ASSIGN || next == TOK_PLUS_EQ || next == TOK_MINUS_EQ ||
                next == TOK_MUL_EQ || next == TOK_DIV_EQ) {
                pos += 2;
                int p = propIndex(name);
                if (next != TOK_ASSIGN) {
                    if (p >= 0) { emit(OP_LOAD_PROP); emit((uint8_t)p); }
                    else { emit(OP_LOAD_VAR); emitU16((uint16_t)getVar(name)); }
                }
                expr();
                if (next == TOK_PLUS_EQ) emit(OP_ADD);
                else if (next == TOK_MINUS_EQ) emit(OP_SUB);
                else if (next == TOK_MUL_EQ) emit(OP_MUL);
                else if (next == TOK_DIV_EQ) emit(OP_DIV);
                if (p >= 0) { emit(OP_STORE_PROP); emit((uint8_t)p); }
                else { emit(OP_STORE_VAR); emitU16((uint16_t)getVar(name)); }
                match(TOK_NL);
                return;
            }
        }
        expr();
        emit(OP_POP);
        match(TOK_NL);
    }

public:
    Bytecode compile(const std::string& src) {
        toks = tokenize(src, bc.error);
        if (!bc.error.empty()) { bc.ok = false; return bc; }
        bc.dtVarIdx = getVar("dt");

        while (cur().type != TOK_EOF && bc.ok) {
            if (match(TOK_NL) || match(TOK_INDENT) || match(TOK_DEDENT)) continue;
            if (match(TOK_START)) {
                match(TOK_COLON);
                size_t skip = emitJump(OP_JMP);
                bc.fnStartIp = (int)bc.code.size();
                block();
                emit(OP_HALT);
                patchJump(skip, (uint16_t)bc.code.size());
            } else if (match(TOK_FRAME)) {
                match(TOK_COLON);
                size_t skip = emitJump(OP_JMP);
                bc.fnFrameIp = (int)bc.code.size();
                block();
                emit(OP_HALT);
                patchJump(skip, (uint16_t)bc.code.size());
            } else {
                statement();
            }
        }
        emit(OP_HALT);
        return bc;
    }
};

inline void execVM(const Bytecode& bc, RuntimeContext& ctx, int startIp) {
    if (!bc.ok || startIp < 0 || startIp >= (int)bc.code.size()) return;
    float stack[256];
    int sp = 0;
    size_t ip = (size_t)startIp;
    const uint8_t* code = bc.code.data();
    size_t n = bc.code.size();
    int steps = 0;

    while (ip < n && steps++ < 50000) {
        uint8_t op = code[ip++];
        switch (op) {
            case OP_CONST: {
                uint16_t idx = code[ip] | (code[ip + 1] << 8); ip += 2;
                stack[sp++] = bc.consts[idx];
                break;
            }
            case OP_LOAD_VAR: {
                uint16_t idx = code[ip] | (code[ip + 1] << 8); ip += 2;
                stack[sp++] = (idx < ctx.vars.size()) ? ctx.vars[idx] : 0.f;
                break;
            }
            case OP_STORE_VAR: {
                uint16_t idx = code[ip] | (code[ip + 1] << 8); ip += 2;
                if (idx >= ctx.vars.size()) ctx.vars.resize(idx + 1, 0.f);
                ctx.vars[idx] = stack[--sp];
                break;
            }
            case OP_LOAD_PROP: {
                uint8_t pid = code[ip++];
                stack[sp++] = ctx.props[pid];
                break;
            }
            case OP_STORE_PROP: {
                uint8_t pid = code[ip++];
                ctx.props[pid] = stack[--sp];
                break;
            }
            case OP_ADD: { float b = stack[--sp]; stack[sp - 1] += b; break; }
            case OP_SUB: { float b = stack[--sp]; stack[sp - 1] -= b; break; }
            case OP_MUL: { float b = stack[--sp]; stack[sp - 1] *= b; break; }
            case OP_DIV: { float b = stack[--sp]; stack[sp - 1] = (b != 0.f) ? (stack[sp - 1] / b) : 0.f; break; }
            case OP_MOD: { float b = stack[--sp]; stack[sp - 1] = std::fmod(stack[sp - 1], b); break; }
            case OP_NEG: { stack[sp - 1] = -stack[sp - 1]; break; }
            case OP_EQ:  { float b = stack[--sp]; stack[sp - 1] = (std::fabs(stack[sp - 1] - b) < 1e-5f) ? 1.f : 0.f; break; }
            case OP_NEQ: { float b = stack[--sp]; stack[sp - 1] = (std::fabs(stack[sp - 1] - b) >= 1e-5f) ? 1.f : 0.f; break; }
            case OP_LT:  { float b = stack[--sp]; stack[sp - 1] = (stack[sp - 1] < b) ? 1.f : 0.f; break; }
            case OP_GT:  { float b = stack[--sp]; stack[sp - 1] = (stack[sp - 1] > b) ? 1.f : 0.f; break; }
            case OP_LE:  { float b = stack[--sp]; stack[sp - 1] = (stack[sp - 1] <= b) ? 1.f : 0.f; break; }
            case OP_GE:  { float b = stack[--sp]; stack[sp - 1] = (stack[sp - 1] >= b) ? 1.f : 0.f; break; }
            case OP_AND: { float b = stack[--sp]; stack[sp - 1] = (stack[sp - 1] != 0.f && b != 0.f) ? 1.f : 0.f; break; }
            case OP_OR:  { float b = stack[--sp]; stack[sp - 1] = (stack[sp - 1] != 0.f || b != 0.f) ? 1.f : 0.f; break; }
            case OP_NOT: { stack[sp - 1] = (stack[sp - 1] == 0.f) ? 1.f : 0.f; break; }
            case OP_JMP: {
                ip = code[ip] | (code[ip + 1] << 8);
                break;
            }
            case OP_JMP_FALSE: {
                uint16_t target = code[ip] | (code[ip + 1] << 8); ip += 2;
                if (stack[--sp] == 0.f) ip = target;
                break;
            }
            case OP_CALL_BUILTIN: {
                uint8_t bid = code[ip++];
                uint8_t argc = code[ip++];
                float res = 0.f;
                if (bid == 1 && argc >= 1) res = std::sin(stack[sp - argc]);
                else if (bid == 2 && argc >= 1) res = std::cos(stack[sp - argc]);
                else if (bid == 3 && argc >= 1) res = std::fabs(stack[sp - argc]);
                else if (bid == 4 && argc >= 2) res = std::fmin(stack[sp - 2], stack[sp - 1]);
                else if (bid == 5 && argc >= 2) res = std::fmax(stack[sp - 2], stack[sp - 1]);
                else if (bid == 6 && argc >= 3) res = std::fmax(stack[sp - 2], std::fmin(stack[sp - 1], stack[sp - 3]));
                else if (bid == 7 && argc >= 3) res = stack[sp - 3] + (stack[sp - 2] - stack[sp - 3]) * stack[sp - 1];
                else if (bid == 8 && argc >= 1) res = std::sqrt(std::fmax(0.f, stack[sp - argc]));
                else if (bid == 9 && argc >= 1) NS_LOG("%.4f", stack[sp - 1]);
                sp -= argc;
                stack[sp++] = res;
                break;
            }
            case OP_POP: { if (sp > 0) sp--; break; }
            case OP_HALT: return;
        }
    }
}

} // namespace ns