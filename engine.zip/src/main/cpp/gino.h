// Gino: node tree + tiny scripting language (RU/EN keywords). No platform deps.
#pragma once
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace gino {

struct Vec3 { float x = 0, y = 0, z = 0; };
struct Error { std::string msg; int line; };

struct Node;
struct Func;

// ------------------------------------------------------------------ values
enum class VT : uint8_t { Nil, Num, Bool, Str, Vec, Node };
struct Value {
    VT t = VT::Nil;
    union { double n; bool b; const std::string* s; Node* node; };
    Vec3 v;
    Value() : n(0) {}
    static Value num(double x) { Value r; r.t = VT::Num; r.n = x; return r; }
    static Value boolean(bool x) { Value r; r.t = VT::Bool; r.b = x; return r; }
    static Value str(const std::string* p) { Value r; r.t = VT::Str; r.s = p; return r; }
    static Value vec(Vec3 p) { Value r; r.t = VT::Vec; r.v = p; return r; }
    static Value ref(Node* p) { Value r; r.t = VT::Node; r.node = p; return r; }
};

// ------------------------------------------------------------------ lexer
enum KW { K_NONE = 0, K_NODE, K_IF, K_ELSE, K_WHILE, K_RETURN, K_FUNC, K_START, K_FRAME,
          K_TAP, K_DRAG, K_AND, K_OR, K_NOT, K_TRUE, K_FALSE };

inline int keywordOf(const std::string& s) {
    static const std::unordered_map<std::string, int> m = {
        {"нода", K_NODE}, {"node", K_NODE},
        {"если", K_IF}, {"if", K_IF},
        {"иначе", K_ELSE}, {"else", K_ELSE},
        {"пока", K_WHILE}, {"while", K_WHILE},
        {"вернуть", K_RETURN}, {"return", K_RETURN},
        {"функция", K_FUNC}, {"func", K_FUNC},
        {"старт", K_START}, {"start", K_START},
        {"кадр", K_FRAME}, {"frame", K_FRAME},
        {"касание", K_TAP}, {"tap", K_TAP},
        {"тяга", K_DRAG}, {"drag", K_DRAG},
        {"и", K_AND}, {"and", K_AND},
        {"или", K_OR}, {"or", K_OR},
        {"не", K_NOT}, {"not", K_NOT},
        {"истина", K_TRUE}, {"true", K_TRUE},
        {"ложь", K_FALSE}, {"false", K_FALSE}};
    auto it = m.find(s);
    return it == m.end() ? K_NONE : it->second;
}

enum class Tok { Num, Str, Ident, Op, End };
struct Token {
    Tok t = Tok::End;
    std::string s;
    double n = 0;
    int kw = 0;
};

inline bool isIdStart(unsigned char c) { return std::isalpha(c) || c == '_' || c >= 0x80; }
inline bool isIdChar(unsigned char c) { return isIdStart(c) || std::isdigit(c); }

inline std::vector<Token> lexLine(const std::string& s, size_t from, int line) {
    std::vector<Token> out;
    size_t i = from;
    while (i < s.size()) {
        unsigned char c = (unsigned char)s[i];
        if (c == ' ' || c == '\t' || c == '\r') { i++; continue; }
        if (c == '#') break;
        Token t;
        if (std::isdigit(c)) {
            size_t j = i;
            while (j < s.size() && std::isdigit((unsigned char)s[j])) j++;
            if (j + 1 < s.size() && s[j] == '.' && std::isdigit((unsigned char)s[j + 1])) {
                j++;
                while (j < s.size() && std::isdigit((unsigned char)s[j])) j++;
            }
            t.t = Tok::Num;
            t.s = s.substr(i, j - i);
            t.n = std::atof(t.s.c_str());
            i = j;
        } else if (isIdStart(c)) {
            size_t j = i;
            while (j < s.size() && isIdChar((unsigned char)s[j])) j++;
            t.t = Tok::Ident;
            t.s = s.substr(i, j - i);
            t.kw = keywordOf(t.s);
            i = j;
        } else if (c == '"') {
            size_t j = i + 1;
            std::string val;
            bool closed = false;
            while (j < s.size()) {
                if (s[j] == '\\' && j + 1 < s.size()) {
                    char e = s[j + 1];
                    val += (e == 'n') ? '\n' : e;
                    j += 2;
                } else if (s[j] == '"') { closed = true; j++; break; }
                else val += s[j++];
            }
            if (!closed) throw Error{"unterminated string", line};
            t.t = Tok::Str;
            t.s = val;
            i = j;
        } else {
            static const char* two[] = {"==", "!=", "<=", ">=", "+=", "-=", "*=", "/="};
            std::string op;
            if (i + 1 < s.size()) {
                std::string p = s.substr(i, 2);
                for (auto* w : two) if (p == w) { op = p; break; }
            }
            if (op.empty()) {
                if (std::strchr("+-*/%(),.=<>", c)) op = std::string(1, (char)c);
                else throw Error{std::string("unexpected character '") + (char)c + "'", line};
            }
            t.t = Tok::Op;
            t.s = op;
            i += op.size();
        }
        out.push_back(t);
    }
    out.push_back(Token{});
    return out;
}

struct LineNode {
    int indent = 0, no = 0;
    std::vector<Token> toks;
    std::vector<std::unique_ptr<LineNode>> kids;
};

inline std::unique_ptr<LineNode> buildTree(const std::string& srcIn) {
    std::string src = srcIn;
    if (src.size() >= 3 && (unsigned char)src[0] == 0xEF && (unsigned char)src[1] == 0xBB &&
        (unsigned char)src[2] == 0xBF)
        src.erase(0, 3);
    auto root = std::make_unique<LineNode>();
    root->indent = -1;
    std::vector<LineNode*> stack{root.get()};
    size_t pos = 0;
    int no = 0;
    while (pos <= src.size()) {
        size_t e = src.find('\n', pos);
        if (e == std::string::npos) e = src.size();
        std::string line = src.substr(pos, e - pos);
        pos = e + 1;
        no++;
        int ind = 0;
        size_t k = 0;
        while (k < line.size() && (line[k] == ' ' || line[k] == '\t')) { ind += (line[k] == '\t') ? 4 : 1; k++; }
        auto toks = lexLine(line, k, no);
        if (toks.size() == 1) continue;
        auto ln = std::make_unique<LineNode>();
        ln->indent = ind;
        ln->no = no;
        ln->toks = std::move(toks);
        while (stack.back()->indent >= ind) stack.pop_back();
        LineNode* p = ln.get();
        stack.back()->kids.push_back(std::move(ln));
        stack.push_back(p);
    }
    return root;
}

// ------------------------------------------------------------------ AST
enum class EK { Num, Bool, Str, Ident, Local, Field, Prop, NodeRef, Self, Parent, Member,
                Call, CallB, CallF, CallM, Unary, Binary, And, Or };
enum Op { OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD, OP_EQ, OP_NE, OP_LT, OP_LE, OP_GT, OP_GE,
          OP_NEG, OP_NOT };

struct Expr {
    EK k;
    int line = 0;
    double num = 0;
    bool bval = false;
    const std::string* str = nullptr;
    std::string name;
    int idx = 0;
    Node* node = nullptr;
    Func* fn = nullptr;
    std::vector<std::unique_ptr<Expr>> a;
    Node* cNode = nullptr;  // member lookup cache
    int cKind = -1, cIdx = 0;
    Expr(EK kk, int ln) : k(kk), line(ln) {}
};
using ExprP = std::unique_ptr<Expr>;

enum class SK { Expr, Assign, If, While, Return };
struct Stmt;
using StmtP = std::unique_ptr<Stmt>;
using Block = std::vector<StmtP>;
struct Stmt {
    SK k;
    int line;
    int op = 0;  // assign: 0 '=', 1 '+=', 2 '-=', 3 '*=', 4 '/='
    ExprP target, e;
    Block body, orelse;
    Stmt(SK kk, int ln) : k(kk), line(ln) {}
};

struct Func {
    std::string name;
    std::vector<std::pair<std::string, int>> names;  // visible names -> slot
    int nParams = 0;
    int nLocals = 0;
    Block body;
    int line = 0;
};

enum class NT { Node3D, Cube, Sphere, Plane, Camera, Light };
enum Prop { P_NONE = -1, P_POS, P_ROT, P_SCL, P_COL, P_FOV, P_ENERGY, P_VISIBLE };

inline int propId(const std::string& s) {
    static const std::unordered_map<std::string, int> m = {
        {"позиция", P_POS}, {"position", P_POS}, {"вращение", P_ROT}, {"rotation", P_ROT},
        {"масштаб", P_SCL}, {"scale", P_SCL}, {"цвет", P_COL}, {"color", P_COL},
        {"обзор", P_FOV}, {"fov", P_FOV}, {"сила", P_ENERGY}, {"energy", P_ENERGY},
        {"видимость", P_VISIBLE}, {"visible", P_VISIBLE}};
    auto it = m.find(s);
    return it == m.end() ? P_NONE : it->second;
}

struct Init {
    std::string name;
    int prop = P_NONE;
    int field = -1;
    ExprP e;
    int line = 0;
};

struct Node {
    std::string name;
    NT type = NT::Node3D;
    int line = 0;
    Node* parent = nullptr;
    std::vector<std::unique_ptr<Node>> kids;
    Vec3 pos{0, 0, 0}, rot{0, 0, 0}, scl{1, 1, 1}, col{1, 1, 1};
    float fov = 60.f, energy = 1.f;
    bool visible = true;
    std::vector<std::string> fieldNames;
    std::vector<Value> fields;
    std::vector<Init> inits;
    std::unordered_map<std::string, std::unique_ptr<Func>> funcs;
    std::unique_ptr<Func> hStart, hFrame, hTap, hDrag;
};

inline bool nodeTypeOf(const std::string& s, NT& out) {
    static const std::unordered_map<std::string, NT> m = {
        {"Нода", NT::Node3D}, {"Node", NT::Node3D}, {"Нода3Д", NT::Node3D}, {"Node3D", NT::Node3D},
        {"Куб", NT::Cube}, {"Cube", NT::Cube}, {"Сфера", NT::Sphere}, {"Sphere", NT::Sphere},
        {"Плоскость", NT::Plane}, {"Plane", NT::Plane}, {"Камера", NT::Camera},
        {"Camera", NT::Camera}, {"Свет", NT::Light}, {"Light", NT::Light}};
    auto it = m.find(s);
    if (it == m.end()) return false;
    out = it->second;
    return true;
}

// ------------------------------------------------------------------ expression parser
struct Parser {
    const std::vector<Token>& t;
    size_t p;
    int line;
    std::deque<std::string>& pool;
    Parser(const std::vector<Token>& tt, size_t start, int ln, std::deque<std::string>& pl)
        : t(tt), p(start), line(ln), pool(pl) {}

    const Token& cur() const { return t[std::min(p, t.size() - 1)]; }
    void adv() { if (p < t.size() - 1) p++; }
    bool atEnd() const { return cur().t == Tok::End; }
    bool isOp(const char* s) const { return cur().t == Tok::Op && cur().s == s; }
    bool isKw(int k) const { return cur().t == Tok::Ident && cur().kw == k; }
    [[noreturn]] void fail(const std::string& m) const { throw Error{m, line}; }
    ExprP mk(EK k) const { return std::make_unique<Expr>(k, line); }
    void expectOp(const char* s) {
        if (!isOp(s)) fail(std::string("expected '") + s + "'");
        adv();
    }
    void expectEnd() { if (!atEnd()) fail("unexpected '" + cur().s + "'"); }

    ExprP parseExpr() { return parseOr(); }
    ExprP bin(EK k, int op, ExprP l, ExprP r) {
        auto e = mk(k);
        e->idx = op;
        e->a.push_back(std::move(l));
        e->a.push_back(std::move(r));
        return e;
    }
    ExprP parseOr() {
        auto l = parseAnd();
        while (isKw(K_OR)) { adv(); l = bin(EK::Or, 0, std::move(l), parseAnd()); }
        return l;
    }
    ExprP parseAnd() {
        auto l = parseNot();
        while (isKw(K_AND)) { adv(); l = bin(EK::And, 0, std::move(l), parseNot()); }
        return l;
    }
    ExprP parseNot() {
        if (isKw(K_NOT)) {
            adv();
            auto e = mk(EK::Unary);
            e->idx = OP_NOT;
            e->a.push_back(parseNot());
            return e;
        }
        return parseCmp();
    }
    ExprP parseCmp() {
        auto l = parseAdd();
        while (cur().t == Tok::Op) {
            int op = -1;
            const std::string& s = cur().s;
            if (s == "==") op = OP_EQ; else if (s == "!=") op = OP_NE;
            else if (s == "<") op = OP_LT; else if (s == "<=") op = OP_LE;
            else if (s == ">") op = OP_GT; else if (s == ">=") op = OP_GE;
            if (op < 0) break;
            adv();
            l = bin(EK::Binary, op, std::move(l), parseAdd());
        }
        return l;
    }
    ExprP parseAdd() {
        auto l = parseMul();
        while (isOp("+") || isOp("-")) {
            int op = isOp("+") ? OP_ADD : OP_SUB;
            adv();
            l = bin(EK::Binary, op, std::move(l), parseMul());
        }
        return l;
    }
    ExprP parseMul() {
        auto l = parseUnary();
        while (isOp("*") || isOp("/") || isOp("%")) {
            int op = isOp("*") ? OP_MUL : (isOp("/") ? OP_DIV : OP_MOD);
            adv();
            l = bin(EK::Binary, op, std::move(l), parseUnary());
        }
        return l;
    }
    ExprP parseUnary() {
        if (isOp("-")) {
            adv();
            auto e = mk(EK::Unary);
            e->idx = OP_NEG;
            e->a.push_back(parseUnary());
            return e;
        }
        return parsePostfix();
    }
    ExprP parsePostfix() {
        auto e = parsePrimary();
        while (true) {
            if (isOp(".")) {
                adv();
                if (cur().t != Tok::Ident || cur().kw) fail("expected a name after '.'");
                auto m = mk(EK::Member);
                m->name = cur().s;
                adv();
                m->a.push_back(std::move(e));
                e = std::move(m);
            } else if (isOp("(")) {
                adv();
                auto c = mk(EK::Call);
                c->a.push_back(std::move(e));
                if (!isOp(")")) {
                    while (true) {
                        c->a.push_back(parseExpr());
                        if (isOp(",")) { adv(); continue; }
                        break;
                    }
                }
                expectOp(")");
                e = std::move(c);
            } else break;
        }
        return e;
    }
    ExprP parsePrimary() {
        const Token& tk = cur();
        if (tk.t == Tok::Num) {
            auto e = mk(EK::Num);
            e->num = tk.n;
            adv();
            return e;
        }
        if (tk.t == Tok::Str) {
            pool.push_back(tk.s);
            auto e = mk(EK::Str);
            e->str = &pool.back();
            adv();
            return e;
        }
        if (tk.t == Tok::Ident) {
            if (tk.kw == K_TRUE || tk.kw == K_FALSE) {
                auto e = mk(EK::Bool);
                e->bval = tk.kw == K_TRUE;
                adv();
                return e;
            }
            if (tk.kw) fail("unexpected keyword '" + tk.s + "'");
            auto e = mk(EK::Ident);
            e->name = tk.s;
            adv();
            return e;
        }
        if (isOp("(")) {
            adv();
            auto e = parseExpr();
            expectOp(")");
            return e;
        }
        if (tk.t == Tok::End) fail("unexpected end of line");
        fail("unexpected '" + tk.s + "'");
    }
};

// ------------------------------------------------------------------ runtime
struct Frame {
    Value loc[32];
    Node* self = nullptr;
    bool returned = false;
    Value ret;
};

enum Builtin { B_PRINT, B_SIN, B_COS, B_TAN, B_ATAN2, B_ABS, B_MIN, B_MAX, B_SQRT, B_FLOOR,
               B_RANDOM, B_VEC, B_LENGTH, B_CLAMP, B_LERP, B_NONE = -1 };

inline int builtinId(const std::string& s) {
    static const std::unordered_map<std::string, int> m = {
        {"печать", B_PRINT}, {"print", B_PRINT}, {"sin", B_SIN}, {"синус", B_SIN},
        {"cos", B_COS}, {"косинус", B_COS}, {"tan", B_TAN}, {"тангенс", B_TAN},
        {"atan2", B_ATAN2}, {"атан2", B_ATAN2}, {"abs", B_ABS}, {"абс", B_ABS},
        {"min", B_MIN}, {"мин", B_MIN}, {"max", B_MAX}, {"макс", B_MAX},
        {"sqrt", B_SQRT}, {"корень", B_SQRT}, {"floor", B_FLOOR}, {"пол", B_FLOOR},
        {"random", B_RANDOM}, {"случайное", B_RANDOM}, {"vec", B_VEC}, {"вектор", B_VEC},
        {"length", B_LENGTH}, {"длина", B_LENGTH}, {"clamp", B_CLAMP}, {"зажать", B_CLAMP},
        {"lerp", B_LERP}, {"смешать", B_LERP}};
    auto it = m.find(s);
    return it == m.end() ? B_NONE : it->second;
}

struct Ctx {
    Node* self = nullptr;
    std::unordered_map<std::string, int> locals;
    int nLocals = 0;
};

struct Scene {
    std::unique_ptr<Node> root;
    std::unordered_map<std::string, Node*> byName;
    std::vector<Node*> order;  // preorder
    std::deque<std::string> pool;
    std::function<void(const std::string&)> printSink;
    std::vector<std::string> errors;
    std::unordered_set<std::string> errSeen;
    long steps = 0;
    int depth = 0;
    uint32_t rng = 2463534242u;

    // ---------------------------------------------------------------- load
    bool load(const std::string& src, std::string& err) {
        try {
            auto tree = buildTree(src);
            if (tree->kids.size() != 1)
                throw Error{"a scene needs exactly one root node", tree->kids.empty() ? 1 : tree->kids[1]->no};
            root = parseNode(*tree->kids[0], nullptr);
            order.clear();
            collect(root.get());
            for (Node* n : order) resolveNode(n);
            return true;
        } catch (Error& e) {
            err = "line " + std::to_string(e.line) + ": " + e.msg;
            return false;
        }
    }

    void collect(Node* n) {
        order.push_back(n);
        for (auto& k : n->kids) collect(k.get());
    }

    // ---------------------------------------------------------------- parse
    std::unique_ptr<Node> parseNode(LineNode& ln, Node* parent) {
        auto& tk = ln.toks;
        if (tk.size() != 4 || tk[0].kw != K_NODE || tk[1].t != Tok::Ident || tk[2].t != Tok::Ident)
            throw Error{"expected: node Type Name", ln.no};
        NT type;
        if (!nodeTypeOf(tk[1].s, type)) throw Error{"unknown node type '" + tk[1].s + "'", ln.no};
        if (tk[2].kw) throw Error{"'" + tk[2].s + "' is a keyword, pick another name", ln.no};
        auto n = std::make_unique<Node>();
        n->type = type;
        n->name = tk[2].s;
        n->line = ln.no;
        n->parent = parent;
        if (byName.count(n->name)) throw Error{"duplicate node name '" + n->name + "'", ln.no};
        byName[n->name] = n.get();

        for (auto& cp : ln.kids) {
            LineNode& c = *cp;
            const Token& f = c.toks[0];
            if (f.t == Tok::Ident && f.kw == K_NODE) {
                n->kids.push_back(parseNode(c, n.get()));
            } else if (f.t == Tok::Ident &&
                       (f.kw == K_START || f.kw == K_FRAME || f.kw == K_TAP || f.kw == K_DRAG)) {
                if (c.toks.size() != 2) throw Error{"'" + f.s + "' takes no arguments here", c.no};
                auto fn = std::make_unique<Func>();
                fn->name = f.s;
                fn->line = c.no;
                if (f.kw == K_FRAME) { fn->names = {{"дт", 0}, {"dt", 0}}; fn->nParams = 1; }
                if (f.kw == K_TAP) { fn->names = {{"тх", 0}, {"tx", 0}, {"ту", 1}, {"ty", 1}}; fn->nParams = 2; }
                if (f.kw == K_DRAG) { fn->names = {{"дх", 0}, {"dx", 0}, {"ду", 1}, {"dy", 1}}; fn->nParams = 2; }
                fn->body = parseBlock(c.kids);
                std::unique_ptr<Func>* slot = f.kw == K_START ? &n->hStart : f.kw == K_FRAME ? &n->hFrame
                                              : f.kw == K_TAP ? &n->hTap : &n->hDrag;
                if (*slot) throw Error{"'" + f.s + "' is defined twice in '" + n->name + "'", c.no};
                *slot = std::move(fn);
            } else if (f.t == Tok::Ident && f.kw == K_FUNC) {
                auto fn = std::make_unique<Func>();
                fn->line = c.no;
                size_t i = 1;
                if (c.toks[i].t != Tok::Ident || c.toks[i].kw) throw Error{"expected a function name", c.no};
                fn->name = c.toks[i++].s;
                if (!(c.toks[i].t == Tok::Op && c.toks[i].s == "(")) throw Error{"expected '('", c.no};
                i++;
                while (!(c.toks[i].t == Tok::Op && c.toks[i].s == ")")) {
                    if (c.toks[i].t != Tok::Ident || c.toks[i].kw) throw Error{"expected a parameter name", c.no};
                    fn->names.push_back({c.toks[i].s, fn->nParams++});
                    i++;
                    if (c.toks[i].t == Tok::Op && c.toks[i].s == ",") i++;
                    else if (!(c.toks[i].t == Tok::Op && c.toks[i].s == ")")) throw Error{"expected ',' or ')'", c.no};
                }
                if (c.toks[i + 1].t != Tok::End) throw Error{"unexpected text after ')'", c.no};
                if (n->funcs.count(fn->name)) throw Error{"function '" + fn->name + "' is defined twice", c.no};
                fn->body = parseBlock(c.kids);
                std::string nm = fn->name;
                n->funcs[nm] = std::move(fn);
            } else if (f.t == Tok::Ident && !f.kw && c.toks.size() > 2 && c.toks[1].t == Tok::Op && c.toks[1].s == "=") {
                Init in;
                in.name = f.s;
                in.line = c.no;
                in.prop = propId(f.s);
                if (in.prop == P_NONE) {
                    for (size_t i = 0; i < n->fieldNames.size(); i++)
                        if (n->fieldNames[i] == f.s) throw Error{"'" + f.s + "' is set twice", c.no};
                    n->fieldNames.push_back(f.s);
                    n->fields.push_back(Value());
                    in.field = (int)n->fieldNames.size() - 1;
                }
                Parser ps(c.toks, 2, c.no, pool);
                in.e = ps.parseExpr();
                ps.expectEnd();
                n->inits.push_back(std::move(in));
            } else {
                throw Error{"unexpected line inside node '" + n->name + "'", c.no};
            }
        }
        return n;
    }

    Block parseBlock(std::vector<std::unique_ptr<LineNode>>& lines) {
        Block out;
        size_t i = 0;
        while (i < lines.size()) {
            LineNode& L = *lines[i];
            const Token& f = L.toks[0];
            if (f.t == Tok::Ident && f.kw == K_IF) {
                out.push_back(parseIf(lines, i, 1));
            } else if (f.t == Tok::Ident && f.kw == K_ELSE) {
                throw Error{"'else' without a matching 'if'", L.no};
            } else if (f.t == Tok::Ident && f.kw == K_WHILE) {
                auto s = std::make_unique<Stmt>(SK::While, L.no);
                Parser ps(L.toks, 1, L.no, pool);
                s->e = ps.parseExpr();
                ps.expectEnd();
                s->body = parseBlock(L.kids);
                out.push_back(std::move(s));
                i++;
            } else if (f.t == Tok::Ident && f.kw == K_RETURN) {
                auto s = std::make_unique<Stmt>(SK::Return, L.no);
                Parser ps(L.toks, 1, L.no, pool);
                if (!ps.atEnd()) s->e = ps.parseExpr();
                ps.expectEnd();
                out.push_back(std::move(s));
                i++;
            } else {
                if (!L.kids.empty()) throw Error{"unexpected indented block", L.kids[0]->no};
                Parser ps(L.toks, 0, L.no, pool);
                auto lhs = ps.parseExpr();
                if (ps.cur().t == Tok::Op && (ps.cur().s == "=" || ps.cur().s == "+=" || ps.cur().s == "-=" ||
                                              ps.cur().s == "*=" || ps.cur().s == "/=")) {
                    if (lhs->k != EK::Ident && lhs->k != EK::Member) throw Error{"cannot assign to this", L.no};
                    auto s = std::make_unique<Stmt>(SK::Assign, L.no);
                    const std::string& o = ps.cur().s;
                    s->op = o == "=" ? 0 : o == "+=" ? 1 : o == "-=" ? 2 : o == "*=" ? 3 : 4;
                    ps.adv();
                    s->target = std::move(lhs);
                    s->e = ps.parseExpr();
                    ps.expectEnd();
                    out.push_back(std::move(s));
                } else {
                    ps.expectEnd();
                    auto s = std::make_unique<Stmt>(SK::Expr, L.no);
                    s->e = std::move(lhs);
                    out.push_back(std::move(s));
                }
                i++;
            }
        }
        return out;
    }

    // lines[i] is an 'if' (condStart=1) or an 'else if' (condStart=2). Advances i past the chain.
    StmtP parseIf(std::vector<std::unique_ptr<LineNode>>& lines, size_t& i, size_t condStart) {
        LineNode& L = *lines[i];
        auto s = std::make_unique<Stmt>(SK::If, L.no);
        Parser ps(L.toks, condStart, L.no, pool);
        s->e = ps.parseExpr();
        ps.expectEnd();
        s->body = parseBlock(L.kids);
        i++;
        if (i < lines.size() && lines[i]->toks[0].t == Tok::Ident && lines[i]->toks[0].kw == K_ELSE) {
            LineNode& E = *lines[i];
            if (E.toks.size() > 2 && E.toks[1].t == Tok::Ident && E.toks[1].kw == K_IF) {
                s->orelse.push_back(parseIf(lines, i, 2));
            } else {
                if (E.toks.size() != 2) throw Error{"unexpected text after 'else'", E.no};
                s->orelse = parseBlock(E.kids);
                i++;
            }
        }
        return s;
    }

    // ---------------------------------------------------------------- resolve
    void resolveNode(Node* n) {
        for (auto& in : n->inits) {
            Ctx c;
            c.self = n;
            rexpr(*in.e, c, false);
        }
        auto doFunc = [&](Func* f) {
            if (!f) return;
            Ctx c;
            c.self = n;
            for (auto& p : f->names) c.locals[p.first] = p.second;
            c.nLocals = f->nParams;
            rblock(f->body, c);
            f->nLocals = c.nLocals;
        };
        doFunc(n->hStart.get());
        doFunc(n->hFrame.get());
        doFunc(n->hTap.get());
        doFunc(n->hDrag.get());
        for (auto& kv : n->funcs) doFunc(kv.second.get());
    }

    void rblock(Block& b, Ctx& c) { for (auto& s : b) rstmt(*s, c); }

    void rstmt(Stmt& s, Ctx& c) {
        switch (s.k) {
            case SK::Expr: rexpr(*s.e, c, false); break;
            case SK::Assign:
                rexpr(*s.e, c, false);
                rexpr(*s.target, c, s.op == 0);
                break;
            case SK::If:
            case SK::While:
                rexpr(*s.e, c, false);
                rblock(s.body, c);
                rblock(s.orelse, c);
                break;
            case SK::Return:
                if (s.e) rexpr(*s.e, c, false);
                break;
        }
    }

    void rexpr(Expr& e, Ctx& c, bool create) {
        switch (e.k) {
            case EK::Ident: resolveName(e, c, create); break;
            case EK::Member: rexpr(*e.a[0], c, false); break;
            case EK::Unary:
            case EK::Binary:
            case EK::And:
            case EK::Or:
                for (auto& k : e.a) rexpr(*k, c, false);
                break;
            case EK::Call: {
                for (size_t i = 1; i < e.a.size(); i++) rexpr(*e.a[i], c, false);
                Expr& callee = *e.a[0];
                if (callee.k == EK::Ident) {
                    auto it = c.self->funcs.find(callee.name);
                    if (it != c.self->funcs.end()) {
                        e.k = EK::CallF;
                        e.fn = it->second.get();
                        e.node = c.self;
                        if ((int)e.a.size() - 1 != e.fn->nParams)
                            throw Error{"'" + callee.name + "' expects " + std::to_string(e.fn->nParams) + " argument(s)", e.line};
                    } else {
                        int b = builtinId(callee.name);
                        if (b == B_NONE) throw Error{"unknown function '" + callee.name + "'", e.line};
                        e.k = EK::CallB;
                        e.idx = b;
                    }
                } else if (callee.k == EK::Member) {
                    rexpr(*callee.a[0], c, false);
                    ExprP cp = std::move(e.a[0]);
                    e.a[0] = std::move(cp->a[0]);
                    e.name = cp->name;
                    e.k = EK::CallM;
                } else {
                    throw Error{"this cannot be called", e.line};
                }
                break;
            }
            default: break;
        }
    }

    void resolveName(Expr& e, Ctx& c, bool create) {
        const std::string& nm = e.name;
        auto it = c.locals.find(nm);
        if (it != c.locals.end()) { e.k = EK::Local; e.idx = it->second; return; }
        for (size_t i = 0; i < c.self->fieldNames.size(); i++)
            if (c.self->fieldNames[i] == nm) { e.k = EK::Field; e.idx = (int)i; e.node = c.self; return; }
        int p = propId(nm);
        if (p != P_NONE) { e.k = EK::Prop; e.idx = p; e.node = c.self; return; }
        if (nm == "я" || nm == "self") { e.k = EK::Self; e.node = c.self; return; }
        if (nm == "родитель" || nm == "parent") { e.k = EK::Parent; e.node = c.self; return; }
        if (nm == "пи" || nm == "pi") { e.k = EK::Num; e.num = 3.14159265358979; return; }
        auto bn = byName.find(nm);
        if (bn != byName.end()) { e.k = EK::NodeRef; e.node = bn->second; return; }
        if (create) {
            if (c.nLocals >= 32) throw Error{"too many variables in one function (max 32)", e.line};
            c.locals[nm] = c.nLocals;
            e.k = EK::Local;
            e.idx = c.nLocals++;
            return;
        }
        throw Error{"unknown name '" + nm + "'", e.line};
    }

    // ---------------------------------------------------------------- properties
    static Value getProp(Node* n, int id) {
        switch (id) {
            case P_POS: return Value::vec(n->pos);
            case P_ROT: return Value::vec(n->rot);
            case P_SCL: return Value::vec(n->scl);
            case P_COL: return Value::vec(n->col);
            case P_FOV: return Value::num(n->fov);
            case P_ENERGY: return Value::num(n->energy);
            default: return Value::boolean(n->visible);
        }
    }
    static void setProp(Node* n, int id, const Value& v, int line) {
        if (id == P_FOV || id == P_ENERGY) {
            if (v.t != VT::Num) throw Error{"expected a number", line};
            (id == P_FOV ? n->fov : n->energy) = (float)v.n;
        } else if (id == P_VISIBLE) {
            if (v.t != VT::Bool) throw Error{"expected true/false", line};
            n->visible = v.b;
        } else {
            if (v.t != VT::Vec) throw Error{"expected a vector, e.g. vec(1, 2, 3)", line};
            Vec3* d = id == P_POS ? &n->pos : id == P_ROT ? &n->rot : id == P_SCL ? &n->scl : &n->col;
            *d = v.v;
        }
    }

    // ---------------------------------------------------------------- eval
    static bool truthy(const Value& v) {
        switch (v.t) {
            case VT::Nil: return false;
            case VT::Bool: return v.b;
            case VT::Num: return v.n != 0;
            default: return true;
        }
    }
    static double needNum(const Value& v, int line) {
        if (v.t != VT::Num) throw Error{"expected a number", line};
        return v.n;
    }
    static Vec3 vadd(Vec3 a, Vec3 b, float s) { return {a.x + s * b.x, a.y + s * b.y, a.z + s * b.z}; }

    static bool equalV(const Value& a, const Value& b) {
        if (a.t != b.t) return false;
        switch (a.t) {
            case VT::Nil: return true;
            case VT::Num: return a.n == b.n;
            case VT::Bool: return a.b == b.b;
            case VT::Str: return *a.s == *b.s;
            case VT::Vec: return a.v.x == b.v.x && a.v.y == b.v.y && a.v.z == b.v.z;
            case VT::Node: return a.node == b.node;
        }
        return false;
    }

    Value binop(int op, const Value& a, const Value& b, int line) {
        if (op == OP_EQ) return Value::boolean(equalV(a, b));
        if (op == OP_NE) return Value::boolean(!equalV(a, b));
        if (a.t == VT::Num && b.t == VT::Num) {
            double x = a.n, y = b.n;
            switch (op) {
                case OP_ADD: return Value::num(x + y);
                case OP_SUB: return Value::num(x - y);
                case OP_MUL: return Value::num(x * y);
                case OP_DIV: return Value::num(x / y);
                case OP_MOD: return Value::num(std::fmod(x, y));
                case OP_LT: return Value::boolean(x < y);
                case OP_LE: return Value::boolean(x <= y);
                case OP_GT: return Value::boolean(x > y);
                case OP_GE: return Value::boolean(x >= y);
            }
        }
        if (a.t == VT::Vec && b.t == VT::Vec) {
            if (op == OP_ADD) return Value::vec(vadd(a.v, b.v, 1));
            if (op == OP_SUB) return Value::vec(vadd(a.v, b.v, -1));
            if (op == OP_MUL) return Value::vec({a.v.x * b.v.x, a.v.y * b.v.y, a.v.z * b.v.z});
        }
        if (a.t == VT::Vec && b.t == VT::Num) {
            float s = (float)b.n;
            if (op == OP_MUL) return Value::vec({a.v.x * s, a.v.y * s, a.v.z * s});
            if (op == OP_DIV) return Value::vec({a.v.x / s, a.v.y / s, a.v.z / s});
        }
        if (a.t == VT::Num && b.t == VT::Vec && op == OP_MUL) {
            float s = (float)a.n;
            return Value::vec({b.v.x * s, b.v.y * s, b.v.z * s});
        }
        if (a.t == VT::Nil || b.t == VT::Nil) throw Error{"a variable has no value yet", line};
        throw Error{"these values cannot be combined with this operator", line};
    }

    static bool vecComp(const std::string& n, int& i) {
        if (n == "x" || n == "r") { i = 0; return true; }
        if (n == "y" || n == "g") { i = 1; return true; }
        if (n == "z" || n == "b") { i = 2; return true; }
        return false;
    }

    void memberLookup(Node* n, Expr& e, int& kind, int& idx) {
        if (e.cNode == n) { kind = e.cKind; idx = e.cIdx; return; }
        int p = propId(e.name);
        if (p != P_NONE) { kind = 0; idx = p; }
        else {
            idx = -1;
            for (size_t i = 0; i < n->fieldNames.size(); i++)
                if (n->fieldNames[i] == e.name) { idx = (int)i; break; }
            if (idx < 0) throw Error{"'" + n->name + "' has no '" + e.name + "'", e.line};
            kind = 1;
        }
        e.cNode = n; e.cKind = kind; e.cIdx = idx;
    }

    Value eval(Expr& e, Frame& f) {
        switch (e.k) {
            case EK::Num: return Value::num(e.num);
            case EK::Bool: return Value::boolean(e.bval);
            case EK::Str: return Value::str(e.str);
            case EK::Local: return f.loc[e.idx];
            case EK::Field: return e.node->fields[e.idx];
            case EK::Prop: return getProp(e.node, e.idx);
            case EK::NodeRef:
            case EK::Self: return Value::ref(e.node);
            case EK::Parent: return e.node->parent ? Value::ref(e.node->parent) : Value();
            case EK::Member: {
                Value b = eval(*e.a[0], f);
                if (b.t == VT::Vec) {
                    int i;
                    if (!vecComp(e.name, i)) throw Error{"a vector only has x, y, z", e.line};
                    const float* c = &b.v.x;
                    return Value::num(c[i]);
                }
                if (b.t == VT::Node) {
                    int kind, idx;
                    memberLookup(b.node, e, kind, idx);
                    return kind == 0 ? getProp(b.node, idx) : b.node->fields[idx];
                }
                throw Error{"this value has no members", e.line};
            }
            case EK::Unary: {
                Value v = eval(*e.a[0], f);
                if (e.idx == OP_NOT) return Value::boolean(!truthy(v));
                if (v.t == VT::Num) return Value::num(-v.n);
                if (v.t == VT::Vec) return Value::vec({-v.v.x, -v.v.y, -v.v.z});
                throw Error{"cannot negate this value", e.line};
            }
            case EK::Binary: {
                Value a = eval(*e.a[0], f);
                Value b = eval(*e.a[1], f);
                return binop(e.idx, a, b, e.line);
            }
            case EK::And: {
                Value a = eval(*e.a[0], f);
                if (!truthy(a)) return Value::boolean(false);
                return Value::boolean(truthy(eval(*e.a[1], f)));
            }
            case EK::Or: {
                Value a = eval(*e.a[0], f);
                if (truthy(a)) return Value::boolean(true);
                return Value::boolean(truthy(eval(*e.a[1], f)));
            }
            case EK::CallB: return callBuiltin(e, f);
            case EK::CallF: {
                std::vector<Value> args;
                for (size_t i = 1; i < e.a.size(); i++) args.push_back(eval(*e.a[i], f));
                return callFunc(*e.fn, e.node, args, e.line);
            }
            case EK::CallM: {
                Value b = eval(*e.a[0], f);
                if (b.t != VT::Node) throw Error{"this value has no functions", e.line};
                auto it = b.node->funcs.find(e.name);
                if (it == b.node->funcs.end()) throw Error{"'" + b.node->name + "' has no function '" + e.name + "'", e.line};
                if ((int)e.a.size() - 1 != it->second->nParams)
                    throw Error{"'" + e.name + "' expects " + std::to_string(it->second->nParams) + " argument(s)", e.line};
                std::vector<Value> args;
                for (size_t i = 1; i < e.a.size(); i++) args.push_back(eval(*e.a[i], f));
                return callFunc(*it->second, b.node, args, e.line);
            }
            default: throw Error{"internal: unresolved expression", e.line};
        }
    }

    void assign(Expr& t, const Value& v, Frame& f) {
        switch (t.k) {
            case EK::Local: f.loc[t.idx] = v; return;
            case EK::Field: t.node->fields[t.idx] = v; return;
            case EK::Prop: setProp(t.node, t.idx, v, t.line); return;
            case EK::Member: {
                Value b = eval(*t.a[0], f);
                if (b.t == VT::Vec) {
                    int i;
                    if (!vecComp(t.name, i)) throw Error{"a vector only has x, y, z", t.line};
                    if (v.t != VT::Num) throw Error{"expected a number", t.line};
                    float* c = &b.v.x;
                    c[i] = (float)v.n;
                    assign(*t.a[0], b, f);
                    return;
                }
                if (b.t == VT::Node) {
                    int kind, idx;
                    memberLookup(b.node, t, kind, idx);
                    if (kind == 0) setProp(b.node, idx, v, t.line);
                    else b.node->fields[idx] = v;
                    return;
                }
                throw Error{"this value has no members", t.line};
            }
            default: throw Error{"cannot assign to this", t.line};
        }
    }

    void run(Stmt& s, Frame& f) {
        if (--steps < 0) throw Error{"script ran too long (endless loop?)", s.line};
        switch (s.k) {
            case SK::Expr: eval(*s.e, f); break;
            case SK::Assign: {
                Value rhs = eval(*s.e, f);
                if (s.op != 0) {
                    Value cur = eval(*s.target, f);
                    static const int ops[] = {0, OP_ADD, OP_SUB, OP_MUL, OP_DIV};
                    rhs = binop(ops[s.op], cur, rhs, s.line);
                }
                assign(*s.target, rhs, f);
                break;
            }
            case SK::If:
                if (truthy(eval(*s.e, f))) exec(s.body, f);
                else exec(s.orelse, f);
                break;
            case SK::While:
                while (truthy(eval(*s.e, f))) {
                    exec(s.body, f);
                    if (f.returned) return;
                    if (--steps < 0) throw Error{"script ran too long (endless loop?)", s.line};
                }
                break;
            case SK::Return:
                if (s.e) f.ret = eval(*s.e, f);
                f.returned = true;
                break;
        }
    }
    void exec(Block& b, Frame& f) {
        for (auto& s : b) {
            run(*s, f);
            if (f.returned) return;
        }
    }

    Value callFunc(Func& fn, Node* self, std::vector<Value>& args, int line) {
        if (depth >= 32) throw Error{"too many nested calls", line};
        Frame fr;
        fr.self = self;
        for (size_t i = 0; i < args.size() && i < 32; i++) fr.loc[i] = args[i];
        depth++;
        try { exec(fn.body, fr); } catch (...) { depth--; throw; }
        depth--;
        return fr.ret;
    }

    float rand01() {
        rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
        return (rng & 0xFFFFFF) / 16777216.0f;
    }

    Value callBuiltin(Expr& e, Frame& f) {
        std::vector<Value> a;
        for (size_t i = 1; i < e.a.size(); i++) a.push_back(eval(*e.a[i], f));
        int L = e.line;
        auto need = [&](size_t n) { if (a.size() != n) throw Error{"wrong number of arguments", L}; };
        const double D2R = 3.14159265358979 / 180.0;
        switch (e.idx) {
            case B_PRINT: {
                std::string s;
                for (size_t i = 0; i < a.size(); i++) { if (i) s += " "; s += format(a[i]); }
                if (printSink) printSink(s); else std::printf("%s\n", s.c_str());
                return Value();
            }
            case B_SIN: need(1); return Value::num(std::sin(needNum(a[0], L) * D2R));
            case B_COS: need(1); return Value::num(std::cos(needNum(a[0], L) * D2R));
            case B_TAN: need(1); return Value::num(std::tan(needNum(a[0], L) * D2R));
            case B_ATAN2: need(2); return Value::num(std::atan2(needNum(a[0], L), needNum(a[1], L)) / D2R);
            case B_ABS: need(1); return Value::num(std::fabs(needNum(a[0], L)));
            case B_SQRT: need(1); return Value::num(std::sqrt(needNum(a[0], L)));
            case B_FLOOR: need(1); return Value::num(std::floor(needNum(a[0], L)));
            case B_MIN: need(2); return Value::num(std::min(needNum(a[0], L), needNum(a[1], L)));
            case B_MAX: need(2); return Value::num(std::max(needNum(a[0], L), needNum(a[1], L)));
            case B_CLAMP: need(3); return Value::num(std::min(std::max(needNum(a[0], L), needNum(a[1], L)), needNum(a[2], L)));
            case B_LERP: {
                need(3);
                double t = needNum(a[2], L);
                if (a[0].t == VT::Num && a[1].t == VT::Num) return Value::num(a[0].n + (a[1].n - a[0].n) * t);
                if (a[0].t == VT::Vec && a[1].t == VT::Vec) {
                    float s = (float)t;
                    return Value::vec({a[0].v.x + (a[1].v.x - a[0].v.x) * s, a[0].v.y + (a[1].v.y - a[0].v.y) * s,
                                       a[0].v.z + (a[1].v.z - a[0].v.z) * s});
                }
                throw Error{"lerp needs two numbers or two vectors", L};
            }
            case B_RANDOM: {
                if (a.empty()) return Value::num(rand01());
                if (a.size() == 1) return Value::num(rand01() * needNum(a[0], L));
                need(2);
                double lo = needNum(a[0], L), hi = needNum(a[1], L);
                return Value::num(lo + rand01() * (hi - lo));
            }
            case B_VEC:
                need(3);
                return Value::vec({(float)needNum(a[0], L), (float)needNum(a[1], L), (float)needNum(a[2], L)});
            case B_LENGTH: {
                need(1);
                if (a[0].t != VT::Vec) throw Error{"length needs a vector", L};
                const Vec3& v = a[0].v;
                return Value::num(std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z));
            }
        }
        return Value();
    }

    static std::string fmtNum(double n) {
        char b[64];
        if (std::fabs(n - std::round(n)) < 1e-9 && std::fabs(n) < 1e9) std::snprintf(b, sizeof b, "%lld", (long long)std::llround(n));
        else std::snprintf(b, sizeof b, "%.4g", n);
        return b;
    }
    static std::string format(const Value& v) {
        switch (v.t) {
            case VT::Nil: return "nil";
            case VT::Num: return fmtNum(v.n);
            case VT::Bool: return v.b ? "true" : "false";
            case VT::Str: return *v.s;
            case VT::Vec: return "(" + fmtNum(v.v.x) + ", " + fmtNum(v.v.y) + ", " + fmtNum(v.v.z) + ")";
            case VT::Node: return "<" + v.node->name + ">";
        }
        return "";
    }

    // ---------------------------------------------------------------- driving the scene
    void report(const Error& e, Node* n) {
        std::string m = "line " + std::to_string(e.line) + ": " + e.msg + " [" + n->name + "]";
        if (errSeen.insert(m).second) {
            errors.push_back(m);
            if (errors.size() > 20) errors.erase(errors.begin());
        }
    }

    void callHandler(Node* n, Func* fn, double a0, double a1, int nargs) {
        if (!fn) return;
        Frame fr;
        fr.self = n;
        if (nargs > 0) fr.loc[0] = Value::num(a0);
        if (nargs > 1) fr.loc[1] = Value::num(a1);
        steps = 200000;
        depth = 0;
        try { exec(fn->body, fr); } catch (Error& e) { report(e, n); }
    }

    void postorderStart(Node* n) {
        for (auto& k : n->kids) postorderStart(k.get());
        callHandler(n, n->hStart.get(), 0, 0, 0);
    }

    void start() {
        if (!root) return;
        for (Node* n : order) {
            for (auto& in : n->inits) {
                Frame fr;
                fr.self = n;
                steps = 200000;
                try {
                    Value v = eval(*in.e, fr);
                    if (in.prop != P_NONE) setProp(n, in.prop, v, in.line);
                    else n->fields[in.field] = v;
                } catch (Error& e) { report(e, n); }
            }
        }
        postorderStart(root.get());
    }

    void update(float dt) {
        for (Node* n : order) callHandler(n, n->hFrame.get(), dt, 0, 1);
    }
    void tap(float x, float y) {
        for (Node* n : order) callHandler(n, n->hTap.get(), x, y, 2);
    }
    void drag(float dx, float dy) {
        for (Node* n : order) callHandler(n, n->hDrag.get(), dx, dy, 2);
    }
};

}  // namespace gino
