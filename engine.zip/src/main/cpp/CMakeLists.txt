cmake_minimum_required(VERSION 3.18)
project(engine LANGUAGES C CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(GLUE_DIR ${ANDROID_NDK}/sources/android/native_app_glue)
add_library(native_app_glue STATIC ${GLUE_DIR}/android_native_app_glue.c)
target_include_directories(native_app_glue PUBLIC ${GLUE_DIR})

add_library(engine SHARED main.cpp)
target_compile_definitions(engine PRIVATE VK_USE_PLATFORM_ANDROID_KHR=1)
target_compile_options(engine PRIVATE -O2 -Wall -fexceptions)
target_link_libraries(engine native_app_glue android log vulkan)
set_target_properties(engine PROPERTIES LINK_FLAGS "-u ANativeActivity_onCreate")
