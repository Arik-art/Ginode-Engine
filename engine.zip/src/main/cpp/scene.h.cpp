#pragma once
#include <cmath>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include "novascript.h"

struct Vec3 { float x = 0, y = 0, z = 0; };
struct Mat4 { float m[16]; };

inline Mat4 matIdentity() {
    Mat4 r{};
    r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.f;
    return r;
}

inline Mat4 matMul(const Mat4& a, const Mat4& b) {
    Mat4 r{};
    for (int c = 0; c < 4; c++)
        for (int row = 0; row < 4; row++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + row] * b.m[c * 4 + k];
            r.m[c * 4 + row] = s;
        }
    return r;
}

inline Mat4 matTRS(Vec3 p, Vec3 r, Vec3 s) {
    float cx = std::cos(r.x), sx = std::sin(r.x);
    float cy = std::cos(r.y), sy = std::sin(r.y);
    float cz = std::cos(r.z), sz = std::sin(r.z);

    Mat4 rx = matIdentity(); rx.m[5] = cx; rx.m[6] = sx; rx.m[9] = -sx; rx.m[10] = cx;
    Mat4 ry = matIdentity(); ry.m[0] = cy; ry.m[2] = -sy; ry.m[8] = sy; ry.m[10] = cy;
    Mat4 rz = matIdentity(); rz.m[0] = cz; rz.m[1] = sz; rz.m[4] = -sz; rz.m[5] = cz;

    Mat4 rot = matMul(ry, matMul(rx, rz));
    Mat4 sc = matIdentity(); sc.m[0] = s.x; sc.m[5] = s.y; sc.m[10] = s.z;
    Mat4 out = matMul(rot, sc);
    out.m[12] = p.x; out.m[13] = p.y; out.m[14] = p.z;
    return out;
}

enum class NodeType {
    Node3D,
    CubeMesh,
    FloorMesh,
    Camera3D
};

struct InputState {
    float x = 0.f;
    float y = 0.f;
    float dx = 0.f;
    float dy = 0.f;
    bool down = false;
    bool tap = false;
    float time = 0.f;
};

struct SceneNode {
    int id = 0;
    std::string name = "Узел";
    NodeType type = NodeType::Node3D;
    Vec3 pos{0, 0, 0};
    Vec3 rot{0, 0, 0};
    Vec3 scale{1, 1, 1};
    Vec3 color{1, 1, 1};

    std::string scriptSource;
    ns::Bytecode bytecode;
    ns::RuntimeContext runtime;
    bool startCalled = false;

    SceneNode* parent = nullptr;
    std::vector<std::unique_ptr<SceneNode>> children;

    Mat4 localTransform() const { return matTRS(pos, rot, scale); }

    Mat4 globalTransform() const {
        if (parent) return matMul(parent->globalTransform(), localTransform());
        return localTransform();
    }

    void compileScript() {
        ns::Compiler comp;
        bytecode = comp.compile(scriptSource);
        runtime = ns::RuntimeContext{};
        InputState empty{};
        syncToRuntime(empty);
        if (bytecode.ok) {
            ns::execVM(bytecode, runtime, 0);
            syncFromRuntime();
        }
        startCalled = false;
    }

    void syncToRuntime(const InputState& in) {
        runtime.props[ns::PROP_POS_X] = pos.x;
        runtime.props[ns::PROP_POS_Y] = pos.y;
        runtime.props[ns::PROP_POS_Z] = pos.z;
        runtime.props[ns::PROP_ROT_X] = rot.x;
        runtime.props[ns::PROP_ROT_Y] = rot.y;
        runtime.props[ns::PROP_ROT_Z] = rot.z;
        runtime.props[ns::PROP_SCALE_X] = scale.x;
        runtime.props[ns::PROP_SCALE_Y] = scale.y;
        runtime.props[ns::PROP_SCALE_Z] = scale.z;
        runtime.props[ns::PROP_COL_R] = color.x;
        runtime.props[ns::PROP_COL_G] = color.y;
        runtime.props[ns::PROP_COL_B] = color.z;
        runtime.props[ns::PROP_TOUCH_X] = in.x;
        runtime.props[ns::PROP_TOUCH_Y] = in.y;
        runtime.props[ns::PROP_TOUCH_DX] = in.dx;
        runtime.props[ns::PROP_TOUCH_DY] = in.dy;
        runtime.props[ns::PROP_TOUCH_DOWN] = in.down ? 1.f : 0.f;
        runtime.props[ns::PROP_TOUCH_TAP] = in.tap ? 1.f : 0.f;
        runtime.props[ns::PROP_TIME] = in.time;
    }

    void syncFromRuntime() {
        pos.x = runtime.props[ns::PROP_POS_X];
        pos.y = runtime.props[ns::PROP_POS_Y];
        pos.z = runtime.props[ns::PROP_POS_Z];
        rot.x = runtime.props[ns::PROP_ROT_X];
        rot.y = runtime.props[ns::PROP_ROT_Y];
        rot.z = runtime.props[ns::PROP_ROT_Z];
        scale.x = runtime.props[ns::PROP_SCALE_X];
        scale.y = runtime.props[ns::PROP_SCALE_Y];
        scale.z = runtime.props[ns::PROP_SCALE_Z];
        color.x = runtime.props[ns::PROP_COL_R];
        color.y = runtime.props[ns::PROP_COL_G];
        color.z = runtime.props[ns::PROP_COL_B];
    }

    void step(bool playing, float dt, const InputState& in) {
        if (playing && !scriptSource.empty() && bytecode.ok) {
            syncToRuntime(in);
            if (!startCalled && bytecode.fnStartIp >= 0) {
                ns::execVM(bytecode, runtime, bytecode.fnStartIp);
                startCalled = true;
            }
            if (bytecode.fnFrameIp >= 0) {
                if (bytecode.dtVarIdx >= 0) {
                    if ((size_t)bytecode.dtVarIdx >= runtime.vars.size())
                        runtime.vars.resize(bytecode.dtVarIdx + 1, 0.f);
                    runtime.vars[bytecode.dtVarIdx] = dt;
                }
                ns::execVM(bytecode, runtime, bytecode.fnFrameIp);
            }
            syncFromRuntime();
        }
        for (auto& ch : children) ch->step(playing, dt, in);
    }

    SceneNode* addChild(const std::string& n, NodeType t, int& nextId) {
        auto node = std::make_unique<SceneNode>();
        node->id = nextId++;
        node->name = n;
        node->type = t;
        node->parent = this;
        SceneNode* ptr = node.get();
        children.push_back(std::move(node));
        return ptr;
    }
};

// Parses declarative scene files written in NovaScript syntax:
// нода Игрок : Куб
//   скорость = 3
//   старт
//     позиция.y = 1
//   кадр
//     вращение.y += скорость * дт
//     если касание
//       скорость = -скорость
inline void loadSceneFromNovaScript(const std::string& text, SceneNode* root, int& nextId) {
    std::istringstream iss(text);
    std::string line;
    struct Frame { SceneNode* node; int indent; };
    std::vector<Frame> stack = {{root, -1}};
    std::vector<SceneNode*> created;

    auto trim = [](const std::string& s) -> std::string {
        size_t a = s.find_first_not_of(" \t\r\n");
        if (a == std::string::npos) return "";
        size_t b = s.find_last_not_of(" \t\r\n");
        return s.substr(a, b - a + 1);
    };

    while (std::getline(iss, line)) {
        int indent = 0;
        size_t i = 0;
        while (i < line.size() && (line[i] == ' ' || line[i] == '\t')) {
            indent += (line[i] == '\t') ? 4 : 1;
            i++;
        }
        std::string content = trim(line);
        if (content.empty() || content[0] == '#') continue;

        while (stack.size() > 1 && indent <= stack.back().indent) {
            stack.pop_back();
        }

        bool isNodeDecl = false;
        std::string rest;
        if (content.rfind("нода ", 0) == 0) { isNodeDecl = true; rest = trim(content.substr(9)); }
        else if (content.rfind("узел ", 0) == 0) { isNodeDecl = true; rest = trim(content.substr(9)); }
        else if (content.rfind("node ", 0) == 0) { isNodeDecl = true; rest = trim(content.substr(5)); }

        if (isNodeDecl) {
            std::string nodeName = rest;
            std::string typeStr = "Node3D";
            size_t colon = rest.find(':');
            if (colon != std::string::npos) {
                nodeName = trim(rest.substr(0, colon));
                typeStr = trim(rest.substr(colon + 1));
            }
            NodeType nt = NodeType::Node3D;
            if (typeStr == "Куб" || typeStr == "Cube") nt = NodeType::CubeMesh;
            else if (typeStr == "Пол" || typeStr == "Floor") nt = NodeType::FloorMesh;
            else if (typeStr == "Камера" || typeStr == "Camera") nt = NodeType::Camera3D;

            SceneNode* n = stack.back().node->addChild(nodeName, nt, nextId);
            stack.push_back({n, indent});
            created.push_back(n);
        } else if (stack.size() > 1) {
            int relIndent = std::max(0, indent - (stack.back().indent + 2));
            stack.back().node->scriptSource += std::string(relIndent, ' ') + content + "\n";
        }
    }

    for (SceneNode* n : created) {
        if (!n->scriptSource.empty()) n->compileScript();
    }
}